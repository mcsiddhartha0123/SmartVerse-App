/*
# ECE Student App — Full Schema

Creates all tables for the ECEHub student app:
- profiles: student info tied to auth.users
- notes: per-user study notes
- internships: ECE internship listings (seeded with real companies)
- cgpa_records: saved CGPA calculations per user
- subscriptions: premium subscription tracking

All tables have RLS. User-owned tables use auth.uid() defaults so inserts work without passing user_id explicitly.
*/

CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL DEFAULT '',
  branch text NOT NULL DEFAULT 'ECE',
  semester int NOT NULL DEFAULT 1,
  avatar_url text,
  is_premium boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT TO authenticated USING (auth.uid() = id);
DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
DROP POLICY IF EXISTS "delete_own_profile" ON profiles;
CREATE POLICY "delete_own_profile" ON profiles FOR DELETE TO authenticated USING (auth.uid() = id);

CREATE TABLE IF NOT EXISTS notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  content text NOT NULL DEFAULT '',
  subject text NOT NULL DEFAULT 'General',
  is_pinned boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE notes ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "select_own_notes" ON notes;
CREATE POLICY "select_own_notes" ON notes FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_notes" ON notes;
CREATE POLICY "insert_own_notes" ON notes FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_notes" ON notes;
CREATE POLICY "update_own_notes" ON notes FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_notes" ON notes;
CREATE POLICY "delete_own_notes" ON notes FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS internships (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company text NOT NULL,
  role text NOT NULL,
  location text NOT NULL DEFAULT 'Remote',
  stipend text,
  duration text,
  skills text[] NOT NULL DEFAULT '{}',
  apply_url text,
  deadline date,
  is_premium_only boolean NOT NULL DEFAULT false,
  posted_at timestamptz DEFAULT now()
);
ALTER TABLE internships ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "select_internships" ON internships;
CREATE POLICY "select_internships" ON internships FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "insert_internships" ON internships;
CREATE POLICY "insert_internships" ON internships FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "update_internships" ON internships;
CREATE POLICY "update_internships" ON internships FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "delete_internships" ON internships;
CREATE POLICY "delete_internships" ON internships FOR DELETE TO authenticated USING (true);

CREATE TABLE IF NOT EXISTS cgpa_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  label text NOT NULL DEFAULT 'My CGPA',
  cgpa numeric(4,2) NOT NULL,
  semester int NOT NULL DEFAULT 1,
  courses jsonb NOT NULL DEFAULT '[]',
  created_at timestamptz DEFAULT now()
);
ALTER TABLE cgpa_records ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "select_own_cgpa" ON cgpa_records;
CREATE POLICY "select_own_cgpa" ON cgpa_records FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_cgpa" ON cgpa_records;
CREATE POLICY "insert_own_cgpa" ON cgpa_records FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_cgpa" ON cgpa_records;
CREATE POLICY "update_own_cgpa" ON cgpa_records FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_cgpa" ON cgpa_records;
CREATE POLICY "delete_own_cgpa" ON cgpa_records FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  plan text NOT NULL DEFAULT 'free',
  status text NOT NULL DEFAULT 'active',
  started_at timestamptz DEFAULT now(),
  expires_at timestamptz
);
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "select_own_sub" ON subscriptions;
CREATE POLICY "select_own_sub" ON subscriptions FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_sub" ON subscriptions;
CREATE POLICY "insert_own_sub" ON subscriptions FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_sub" ON subscriptions;
CREATE POLICY "update_own_sub" ON subscriptions FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_sub" ON subscriptions;
CREATE POLICY "delete_own_sub" ON subscriptions FOR DELETE TO authenticated USING (auth.uid() = user_id);

INSERT INTO internships (company, role, location, stipend, duration, skills, apply_url, deadline, is_premium_only)
VALUES
  ('Texas Instruments','VLSI Design Intern','Bengaluru','₹40,000/mo','6 months',ARRAY['VLSI','Verilog','CMOS','Cadence'],'https://careers.ti.com','2026-07-31',false),
  ('Qualcomm','Embedded Systems Intern','Hyderabad','₹50,000/mo','3 months',ARRAY['C','RTOS','ARM','Linux'],'https://careers.qualcomm.com','2026-07-15',false),
  ('Samsung R&D','Signal Processing Intern','Bengaluru','₹35,000/mo','6 months',ARRAY['DSP','MATLAB','Python','FPGA'],'https://research.samsung.com/careers','2026-08-01',true),
  ('Intel','Hardware Engineer Intern','Bengaluru','₹60,000/mo','4 months',ARRAY['PCB Design','FPGA','Verilog','Altium'],'https://jobs.intel.com','2026-07-20',true),
  ('ISRO','Electronics Intern','Ahmedabad','₹15,000/mo','2 months',ARRAY['RF','Antenna Design','PCB','Simulation'],'https://isro.gov.in/careers','2026-06-30',false),
  ('Bosch','Automotive Electronics Intern','Pune','₹30,000/mo','6 months',ARRAY['CAN Bus','Embedded C','Autosar','MATLAB'],'https://bosch.com/careers','2026-08-15',false)
ON CONFLICT DO NOTHING;
