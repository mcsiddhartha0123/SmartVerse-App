export const colors = {
  bg: '#0C0F16',
  bgCard: '#161B26',
  bgElevated: '#1F2633',
  border: '#2A3344',
  blue: '#3B82F6',
  blueLight: '#60A5FA',
  blueDark: '#1D4ED8',
  blueGlow: 'rgba(59,130,246,0.15)',
  textPrimary: '#F1F5F9',
  textSecondary: '#94A3B8',
  textMuted: '#475569',
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
  premium: '#F59E0B',
  premiumBg: 'rgba(245,158,11,0.12)',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  full: 999,
};

export const font = {
  xs: 11,
  sm: 13,
  md: 15,
  lg: 17,
  xl: 20,
  xxl: 24,
  xxxl: 32,
};
