import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import {
  ChevronLeft,
  User,
  GraduationCap,
  BookOpen,
  Crown,
  LogOut,
  Save,
  Check,
  ChevronDown,
  ChevronUp,
  ChevronRight,
  Settings,
} from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { colors, spacing, radius, font } from '@/constants/theme';

const BRANCHES = ['ECE', 'EEE', 'CSE', 'ME', 'CE', 'IT'];
const SEMESTERS = [1, 2, 3, 4, 5, 6, 7, 8];

export default function ProfileScreen() {
  const { user, signOut } = useAuth();
  const [fullName, setFullName] = useState('');
  const [branch, setBranch] = useState('ECE');
  const [semester, setSemester] = useState(1);
  const [isPremium, setIsPremium] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [showBranch, setShowBranch] = useState(false);
  const [showSemester, setShowSemester] = useState(false);

  useEffect(() => {
    loadProfile();
  }, [user]);

  const loadProfile = async () => {
    if (!user) return;
    setLoading(true);
    const { data } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .maybeSingle();
    if (data) {
      setFullName(data.full_name || '');
      setBranch(data.branch || 'ECE');
      setSemester(data.semester || 1);
      setIsPremium(data.is_premium || false);
    }
    setLoading(false);
  };

  const saveProfile = async () => {
    if (!user) return;
    setSaving(true);
    await supabase
      .from('profiles')
      .upsert({ id: user.id, full_name: fullName, branch, semester })
      .eq('id', user.id);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const handleSignOut = async () => {
    await signOut();
    router.replace('/auth/login');
  };

  const initials = fullName
    ? fullName.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase()
    : user?.email?.[0]?.toUpperCase() ?? '?';

  if (loading) {
    return (
      <View style={styles.loadingWrap}>
        <ActivityIndicator color={colors.blue} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <SafeAreaView edges={['top']} style={styles.safeArea}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn} activeOpacity={0.7}>
            <ChevronLeft size={24} color={colors.textPrimary} strokeWidth={2} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Profile</Text>
          <View style={{ width: 40 }} />
        </View>

        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
          {/* Avatar */}
          <View style={styles.avatarSection}>
            <LinearGradient colors={[colors.blue, colors.blueDark]} style={styles.avatar}>
              <Text style={styles.avatarText}>{initials}</Text>
            </LinearGradient>
            {isPremium && (
              <View style={styles.premiumBadge}>
                <Crown size={12} color={colors.premium} strokeWidth={2} />
                <Text style={styles.premiumBadgeText}>Premium</Text>
              </View>
            )}
            <Text style={styles.avatarEmail}>{user?.email}</Text>
          </View>

          {/* Form */}
          <View style={styles.card}>
            <Text style={styles.sectionTitle}>Personal Info</Text>

            <View style={styles.field}>
              <Text style={styles.label}>Full Name</Text>
              <View style={styles.inputWrap}>
                <User size={16} color={colors.textMuted} strokeWidth={1.5} style={styles.inputIcon} />
                <TextInput
                  style={styles.input}
                  value={fullName}
                  onChangeText={setFullName}
                  placeholder="Your full name"
                  placeholderTextColor={colors.textMuted}
                  autoCapitalize="words"
                />
              </View>
            </View>

            <View style={styles.field}>
              <Text style={styles.label}>Branch</Text>
              <TouchableOpacity
                style={styles.selectWrap}
                onPress={() => { setShowBranch(!showBranch); setShowSemester(false); }}
                activeOpacity={0.8}
              >
                <GraduationCap size={16} color={colors.textMuted} strokeWidth={1.5} style={styles.inputIcon} />
                <Text style={styles.selectText}>{branch}</Text>
                {showBranch
                  ? <ChevronUp size={16} color={colors.textMuted} strokeWidth={2} />
                  : <ChevronDown size={16} color={colors.textMuted} strokeWidth={2} />
                }
              </TouchableOpacity>
              {showBranch && (
                <View style={styles.dropdown}>
                  {BRANCHES.map((b) => (
                    <TouchableOpacity
                      key={b}
                      style={[styles.dropdownItem, branch === b && styles.dropdownItemActive]}
                      onPress={() => { setBranch(b); setShowBranch(false); }}
                    >
                      <Text style={[styles.dropdownText, branch === b && styles.dropdownTextActive]}>{b}</Text>
                      {branch === b && <Check size={14} color={colors.blue} strokeWidth={2.5} />}
                    </TouchableOpacity>
                  ))}
                </View>
              )}
            </View>

            <View style={styles.field}>
              <Text style={styles.label}>Current Semester</Text>
              <TouchableOpacity
                style={styles.selectWrap}
                onPress={() => { setShowSemester(!showSemester); setShowBranch(false); }}
                activeOpacity={0.8}
              >
                <BookOpen size={16} color={colors.textMuted} strokeWidth={1.5} style={styles.inputIcon} />
                <Text style={styles.selectText}>Semester {semester}</Text>
                {showSemester
                  ? <ChevronUp size={16} color={colors.textMuted} strokeWidth={2} />
                  : <ChevronDown size={16} color={colors.textMuted} strokeWidth={2} />
                }
              </TouchableOpacity>
              {showSemester && (
                <View style={styles.dropdown}>
                  {SEMESTERS.map((s) => (
                    <TouchableOpacity
                      key={s}
                      style={[styles.dropdownItem, semester === s && styles.dropdownItemActive]}
                      onPress={() => { setSemester(s); setShowSemester(false); }}
                    >
                      <Text style={[styles.dropdownText, semester === s && styles.dropdownTextActive]}>
                        Semester {s}
                      </Text>
                      {semester === s && <Check size={14} color={colors.blue} strokeWidth={2.5} />}
                    </TouchableOpacity>
                  ))}
                </View>
              )}
            </View>

            <TouchableOpacity
              style={styles.saveBtn}
              onPress={saveProfile}
              disabled={saving}
              activeOpacity={0.85}
            >
              <LinearGradient
                colors={saved ? [colors.success, '#059669'] : [colors.blue, colors.blueDark]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.saveBtnGrad}
              >
                {saving ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <>
                    {saved
                      ? <Check size={18} color="#fff" strokeWidth={2.5} />
                      : <Save size={18} color="#fff" strokeWidth={1.5} />
                    }
                    <Text style={styles.saveBtnText}>
                      {saving ? 'Saving...' : saved ? 'Saved!' : 'Save Changes'}
                    </Text>
                  </>
                )}
              </LinearGradient>
            </TouchableOpacity>
          </View>

          {/* Subscription */}
          <View style={styles.card}>
            <Text style={styles.sectionTitle}>Subscription</Text>
            <View style={styles.subRow}>
              <View style={[styles.subBadge, isPremium ? styles.subBadgePro : styles.subBadgeFree]}>
                {isPremium
                  ? <Crown size={16} color={colors.premium} strokeWidth={1.5} />
                  : <BookOpen size={16} color={colors.textMuted} strokeWidth={1.5} />
                }
                <Text style={[styles.subBadgeText, isPremium ? styles.subBadgeTextPro : styles.subBadgeTextFree]}>
                  {isPremium ? 'ECEHub Pro' : 'Free Plan'}
                </Text>
              </View>
              {!isPremium && (
                <TouchableOpacity
                  style={styles.upgradeBtn}
                  onPress={() => router.push('/(tabs)/premium')}
                  activeOpacity={0.85}
                >
                  <LinearGradient colors={[colors.premium, '#D97706']} style={styles.upgradeBtnGrad}>
                    <Text style={styles.upgradeBtnText}>Upgrade</Text>
                  </LinearGradient>
                </TouchableOpacity>
              )}
            </View>
          </View>

          {/* Settings Link */}
          <TouchableOpacity
            style={styles.settingsBtn}
            onPress={() => router.push('/settings')}
            activeOpacity={0.8}
          >
            <Settings size={18} color={colors.textSecondary} strokeWidth={1.5} />
            <Text style={styles.settingsBtnText}>App Settings</Text>
            <ChevronRight size={16} color={colors.textMuted} strokeWidth={2} />
          </TouchableOpacity>

          {/* Sign out */}
          <TouchableOpacity style={styles.signOutBtn} onPress={handleSignOut} activeOpacity={0.8}>
            <LogOut size={18} color={colors.error} strokeWidth={1.5} />
            <Text style={styles.signOutText}>Sign Out</Text>
          </TouchableOpacity>

          <View style={{ height: 80 }} />
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  safeArea: { flex: 1 },
  loadingWrap: { flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },
  backBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontSize: font.lg, fontWeight: '700', color: colors.textPrimary },
  scroll: { paddingHorizontal: spacing.md, paddingTop: spacing.sm },
  avatarSection: { alignItems: 'center', marginBottom: spacing.lg },
  avatar: {
    width: 88,
    height: 88,
    borderRadius: radius.full,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.sm,
    shadowColor: colors.blue,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.3,
    shadowRadius: 16,
    elevation: 8,
  },
  avatarText: { fontSize: font.xxxl, fontWeight: '800', color: '#fff' },
  premiumBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: colors.premiumBg,
    borderRadius: radius.full,
    paddingHorizontal: spacing.md,
    paddingVertical: 4,
    borderWidth: 1,
    borderColor: 'rgba(245,158,11,0.3)',
    marginBottom: spacing.xs,
  },
  premiumBadgeText: { fontSize: font.xs, color: colors.premium, fontWeight: '700' },
  avatarEmail: { fontSize: font.sm, color: colors.textSecondary },
  card: {
    backgroundColor: colors.bgCard,
    borderRadius: radius.xl,
    padding: spacing.lg,
    borderWidth: 1,
    borderColor: colors.border,
    marginBottom: spacing.md,
  },
  sectionTitle: {
    fontSize: font.md,
    fontWeight: '700',
    color: colors.textPrimary,
    marginBottom: spacing.md,
  },
  field: { marginBottom: spacing.md },
  label: {
    fontSize: font.xs,
    fontWeight: '600',
    color: colors.textSecondary,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginBottom: spacing.xs,
  },
  inputWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bgElevated,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: spacing.md,
    height: 48,
  },
  inputIcon: { marginRight: spacing.sm },
  input: { flex: 1, color: colors.textPrimary, fontSize: font.md },
  selectWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bgElevated,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: spacing.md,
    height: 48,
  },
  selectText: { flex: 1, color: colors.textPrimary, fontSize: font.md },
  dropdown: {
    backgroundColor: colors.bgElevated,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    marginTop: 4,
    overflow: 'hidden',
  },
  dropdownItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  dropdownItemActive: { backgroundColor: colors.blueGlow },
  dropdownText: { fontSize: font.sm, color: colors.textSecondary },
  dropdownTextActive: { color: colors.blue, fontWeight: '600' },
  saveBtn: { borderRadius: radius.md, overflow: 'hidden', marginTop: spacing.sm },
  saveBtnGrad: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.xs,
    height: 52,
  },
  saveBtnText: { color: '#fff', fontSize: font.md, fontWeight: '700' },
  subRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  subBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: radius.md,
    borderWidth: 1,
  },
  subBadgeFree: { backgroundColor: colors.bgElevated, borderColor: colors.border },
  subBadgePro: { backgroundColor: colors.premiumBg, borderColor: 'rgba(245,158,11,0.3)' },
  subBadgeText: { fontSize: font.sm, fontWeight: '700' },
  subBadgeTextFree: { color: colors.textSecondary },
  subBadgeTextPro: { color: colors.premium },
  upgradeBtn: { borderRadius: radius.md, overflow: 'hidden' },
  upgradeBtnGrad: { paddingHorizontal: spacing.lg, paddingVertical: spacing.sm },
  upgradeBtnText: { color: '#fff', fontSize: font.sm, fontWeight: '700' },
  settingsBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.bgCard,
    paddingHorizontal: spacing.md,
    marginBottom: spacing.md,
  },
  settingsBtnText: { flex: 1, color: colors.textPrimary, fontSize: font.md, fontWeight: '500' },
  signOutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.3)',
    backgroundColor: 'rgba(239,68,68,0.08)',
  },
  signOutText: { color: colors.error, fontSize: font.md, fontWeight: '600' },
});
