import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  Animated,
  Pressable,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  Bell,
  TrendingUp,
  BookOpen,
  Briefcase,
  Crown,
  ChevronRight,
  Cpu,
  Zap,
  Award,
  X,
  Clock,
  AlertCircle,
  Info,
  User,
} from 'lucide-react-native';
import { router } from 'expo-router';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { colors, spacing, radius, font } from '@/constants/theme';

const ECE_SUBJECTS = [
  { code: 'EC301', name: 'Digital Signal Processing', credits: 4, subject: 'DSP' },
  { code: 'EC302', name: 'VLSI Design', credits: 3, subject: 'VLSI' },
  { code: 'EC303', name: 'Microprocessors', credits: 4, subject: 'Microprocessors' },
  { code: 'EC304', name: 'Communication Systems', credits: 4, subject: 'Communication' },
];

const QUICK_TIPS = [
  'Review Z-transforms before your DSP exam.',
  'TI internship deadline is approaching fast.',
  'Pin important notes for quick access during exams.',
  'Save your CGPA every semester to track progress.',
];

const NOTIFICATIONS = [
  {
    id: '1',
    type: 'deadline',
    title: 'Internship Deadline',
    body: 'ISRO application closes in 12 days.',
    time: '2h ago',
    icon: AlertCircle,
    color: colors.warning,
  },
  {
    id: '2',
    type: 'tip',
    title: 'Study Tip',
    body: 'Digital Signal Processing — practice past papers.',
    time: '5h ago',
    icon: Info,
    color: colors.blue,
  },
  {
    id: '3',
    type: 'premium',
    title: 'New Listing',
    body: 'Samsung R&D opened a new Signal Processing role.',
    time: '1d ago',
    icon: Briefcase,
    color: colors.success,
  },
  {
    id: '4',
    type: 'tip',
    title: 'CGPA Alert',
    body: "You haven't saved your CGPA this semester yet.",
    time: '2d ago',
    icon: TrendingUp,
    color: colors.error,
  },
];

function getGreeting() {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning,';
  if (h < 17) return 'Good afternoon,';
  if (h < 21) return 'Good evening,';
  return 'Good night,';
}

interface Profile {
  full_name: string;
  branch: string;
  semester: number;
  is_premium: boolean;
}

export default function DashboardScreen() {
  const { user } = useAuth();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [cgpa, setCgpa] = useState<number | null>(null);
  const [notesCount, setNotesCount] = useState(0);
  const [tipIndex, setTipIndex] = useState(0);
  const [notifOpen, setNotifOpen] = useState(false);
  const slideAnim = useRef(new Animated.Value(400)).current;
  const backdropAnim = useRef(new Animated.Value(0)).current;

  const loadData = async () => {
    if (!user) return;
    const [profileRes, cgpaRes, notesRes] = await Promise.all([
      supabase.from('profiles').select('*').eq('id', user.id).maybeSingle(),
      supabase
        .from('cgpa_records')
        .select('cgpa')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle(),
      supabase.from('notes').select('id', { count: 'exact' }).eq('user_id', user.id),
    ]);
    if (profileRes.data) setProfile(profileRes.data);
    if (cgpaRes.data) setCgpa(cgpaRes.data.cgpa);
    if (notesRes.count !== null) setNotesCount(notesRes.count);
  };

  useEffect(() => {
    loadData();
    const interval = setInterval(() => {
      setTipIndex((i) => (i + 1) % QUICK_TIPS.length);
    }, 4000);
    return () => clearInterval(interval);
  }, [user]);

  const onRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  const openNotifications = () => {
    setNotifOpen(true);
    Animated.parallel([
      Animated.spring(slideAnim, { toValue: 0, useNativeDriver: true, tension: 80, friction: 12 }),
      Animated.timing(backdropAnim, { toValue: 1, duration: 200, useNativeDriver: true }),
    ]).start();
  };

  const closeNotifications = () => {
    Animated.parallel([
      Animated.spring(slideAnim, { toValue: 400, useNativeDriver: true, tension: 80, friction: 12 }),
      Animated.timing(backdropAnim, { toValue: 0, duration: 150, useNativeDriver: true }),
    ]).start(() => setNotifOpen(false));
  };

  const displayName = profile?.full_name || user?.email?.split('@')[0] || 'Student';
  const initials = displayName
    .split(' ')
    .map((n: string) => n[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();

  return (
    <View style={styles.container}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scroll}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.blue} />
        }
      >
        <SafeAreaView edges={['top']}>
          {/* Header */}
          <View style={styles.headerRow}>
            <TouchableOpacity
              style={styles.avatarWrap}
              onPress={() => router.push('/profile')}
              activeOpacity={0.8}
            >
              <LinearGradient colors={[colors.blue, colors.blueDark]} style={styles.avatar}>
                <Text style={styles.avatarText}>{initials}</Text>
              </LinearGradient>
              {profile?.is_premium && (
                <View style={styles.premiumBadge}>
                  <Crown size={10} color={colors.premium} strokeWidth={2} />
                </View>
              )}
            </TouchableOpacity>
            <View style={styles.headerInfo}>
              <Text style={styles.greeting}>{getGreeting()}</Text>
              <Text style={styles.name} numberOfLines={1}>
                {displayName}
              </Text>
            </View>
            <TouchableOpacity
              style={styles.bellBtn}
              onPress={openNotifications}
              activeOpacity={0.8}
            >
              <Bell size={22} color={colors.textSecondary} strokeWidth={1.5} />
              <View style={styles.bellDot} />
            </TouchableOpacity>
          </View>

          {/* Banner */}
          <LinearGradient
            colors={['#1E3A5F', '#0F2440']}
            style={styles.banner}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
          >
            <View style={styles.bannerLeft}>
              <Text style={styles.bannerLabel}>QUICK TIP</Text>
              <Text style={styles.bannerText}>{QUICK_TIPS[tipIndex]}</Text>
            </View>
            <Zap size={36} color={colors.blueLight} strokeWidth={1} style={{ opacity: 0.4 }} />
          </LinearGradient>

          {/* Stats Row */}
          <View style={styles.statsRow}>
            <TouchableOpacity
              style={styles.statCard}
              onPress={() => router.push('/(tabs)/cgpa')}
              activeOpacity={0.8}
            >
              <LinearGradient colors={[colors.bgElevated, colors.bgCard]} style={styles.statGrad}>
                <TrendingUp size={22} color={colors.blue} strokeWidth={1.5} />
                <Text style={styles.statValue}>{cgpa ? cgpa.toFixed(2) : '--'}</Text>
                <Text style={styles.statLabel}>CGPA</Text>
              </LinearGradient>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.statCard}
              onPress={() => router.push('/(tabs)/notes')}
              activeOpacity={0.8}
            >
              <LinearGradient colors={[colors.bgElevated, colors.bgCard]} style={styles.statGrad}>
                <BookOpen size={22} color={colors.success} strokeWidth={1.5} />
                <Text style={styles.statValue}>{notesCount}</Text>
                <Text style={styles.statLabel}>Notes</Text>
              </LinearGradient>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.statCard}
              onPress={() => router.push('/(tabs)/internships')}
              activeOpacity={0.8}
            >
              <LinearGradient colors={[colors.bgElevated, colors.bgCard]} style={styles.statGrad}>
                <Briefcase size={22} color={colors.warning} strokeWidth={1.5} />
                <Text style={styles.statValue}>6</Text>
                <Text style={styles.statLabel}>Jobs</Text>
              </LinearGradient>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.statCard}
              onPress={() => router.push('/profile')}
              activeOpacity={0.8}
            >
              <LinearGradient colors={[colors.bgElevated, colors.bgCard]} style={styles.statGrad}>
                <Award size={22} color={colors.premium} strokeWidth={1.5} />
                <Text style={styles.statValue}>
                  {profile?.semester ? `Sem ${profile.semester}` : 'S1'}
                </Text>
                <Text style={styles.statLabel}>Semester</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>

          {/* ECE Subjects — tappable, navigate to notes filtered by subject */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Cpu size={18} color={colors.blue} strokeWidth={1.5} />
              <Text style={styles.sectionTitle}>ECE Core Subjects</Text>
            </View>
            {ECE_SUBJECTS.map((sub) => (
              <TouchableOpacity
                key={sub.code}
                style={styles.subjectCard}
                onPress={() => router.push('/(tabs)/notes')}
                activeOpacity={0.8}
              >
                <View style={styles.subjectLeft}>
                  <Text style={styles.subjectCode}>{sub.code}</Text>
                  <Text style={styles.subjectName}>{sub.name}</Text>
                </View>
                <View style={styles.subjectRight}>
                  <View style={styles.creditsTag}>
                    <Text style={styles.creditsText}>{sub.credits} cr</Text>
                  </View>
                  <ChevronRight size={16} color={colors.textMuted} strokeWidth={1.5} />
                </View>
              </TouchableOpacity>
            ))}
          </View>

          {/* Quick Actions */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Zap size={18} color={colors.blue} strokeWidth={1.5} />
              <Text style={styles.sectionTitle}>Quick Actions</Text>
            </View>
            <View style={styles.actionsGrid}>
              {[
                { label: 'Calculate CGPA', icon: TrendingUp, route: '/(tabs)/cgpa', color: colors.blue },
                { label: 'Add Note', icon: BookOpen, route: '/(tabs)/notes', color: colors.success },
                { label: 'Find Internship', icon: Briefcase, route: '/(tabs)/internships', color: colors.warning },
                { label: 'Go Premium', icon: Crown, route: '/(tabs)/premium', color: colors.premium },
              ].map((action) => (
                <TouchableOpacity
                  key={action.label}
                  style={styles.actionCard}
                  onPress={() => router.push(action.route as any)}
                  activeOpacity={0.8}
                >
                  <View style={[styles.actionIcon, { backgroundColor: action.color + '22' }]}>
                    <action.icon size={20} color={action.color} strokeWidth={1.5} />
                  </View>
                  <Text style={styles.actionLabel}>{action.label}</Text>
                  <ChevronRight size={14} color={colors.textMuted} strokeWidth={2} />
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* Profile link */}
          <TouchableOpacity
            style={styles.profileBtn}
            onPress={() => router.push('/profile')}
            activeOpacity={0.8}
          >
            <User size={16} color={colors.textSecondary} strokeWidth={1.5} />
            <Text style={styles.profileBtnText}>View Profile & Settings</Text>
            <ChevronRight size={14} color={colors.textMuted} strokeWidth={1.5} />
          </TouchableOpacity>

          <View style={{ height: 80 }} />
        </SafeAreaView>
      </ScrollView>

      {/* Notifications Drawer */}
      {notifOpen && (
        <>
          <Animated.View style={[styles.backdrop, { opacity: backdropAnim }]}>
            <Pressable style={StyleSheet.absoluteFillObject} onPress={closeNotifications} />
          </Animated.View>
          <Animated.View
            style={[styles.notifDrawer, { transform: [{ translateX: slideAnim }] }]}
          >
            <SafeAreaView edges={['top', 'right']} style={{ flex: 1 }}>
              <View style={styles.notifHeader}>
                <Text style={styles.notifTitle}>Notifications</Text>
                <TouchableOpacity onPress={closeNotifications} style={styles.notifClose}>
                  <X size={20} color={colors.textSecondary} strokeWidth={1.5} />
                </TouchableOpacity>
              </View>
              <ScrollView contentContainerStyle={styles.notifScroll}>
                {NOTIFICATIONS.map((n) => (
                  <View key={n.id} style={styles.notifCard}>
                    <View style={[styles.notifIcon, { backgroundColor: n.color + '22' }]}>
                      <n.icon size={18} color={n.color} strokeWidth={1.5} />
                    </View>
                    <View style={styles.notifBody}>
                      <Text style={styles.notifItemTitle}>{n.title}</Text>
                      <Text style={styles.notifItemBody}>{n.body}</Text>
                      <View style={styles.notifTimeRow}>
                        <Clock size={11} color={colors.textMuted} strokeWidth={1.5} />
                        <Text style={styles.notifTime}>{n.time}</Text>
                      </View>
                    </View>
                  </View>
                ))}
              </ScrollView>
            </SafeAreaView>
          </Animated.View>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  scroll: { paddingHorizontal: spacing.md },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: spacing.sm,
    paddingBottom: spacing.md,
    gap: spacing.sm,
  },
  avatarWrap: { position: 'relative' },
  avatar: {
    width: 46,
    height: 46,
    borderRadius: radius.full,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: { color: '#fff', fontWeight: '700', fontSize: font.md },
  premiumBadge: {
    position: 'absolute',
    bottom: -2,
    right: -2,
    width: 18,
    height: 18,
    borderRadius: radius.full,
    backgroundColor: colors.premiumBg,
    borderWidth: 1,
    borderColor: colors.premium,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerInfo: { flex: 1 },
  greeting: { fontSize: font.xs, color: colors.textMuted },
  name: { fontSize: font.lg, fontWeight: '700', color: colors.textPrimary },
  bellBtn: { position: 'relative', padding: spacing.xs },
  bellDot: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 7,
    height: 7,
    borderRadius: 4,
    backgroundColor: colors.blue,
    borderWidth: 1,
    borderColor: colors.bg,
  },
  banner: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: radius.lg,
    padding: spacing.md,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: 'rgba(59,130,246,0.2)',
  },
  bannerLeft: { flex: 1 },
  bannerLabel: {
    fontSize: font.xs,
    fontWeight: '700',
    color: colors.blueLight,
    letterSpacing: 1,
    marginBottom: 4,
  },
  bannerText: { fontSize: font.sm, color: colors.textSecondary, lineHeight: 18 },
  statsRow: { flexDirection: 'row', gap: spacing.sm, marginBottom: spacing.md },
  statCard: { flex: 1, borderRadius: radius.md, overflow: 'hidden' },
  statGrad: {
    alignItems: 'center',
    padding: spacing.sm,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    gap: 4,
  },
  statValue: { fontSize: font.md, fontWeight: '700', color: colors.textPrimary },
  statLabel: { fontSize: font.xs, color: colors.textMuted },
  section: { marginBottom: spacing.lg },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    marginBottom: spacing.sm,
  },
  sectionTitle: { fontSize: font.md, fontWeight: '700', color: colors.textPrimary },
  subjectCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bgCard,
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.xs,
    borderWidth: 1,
    borderColor: colors.border,
  },
  subjectLeft: { flex: 1 },
  subjectCode: { fontSize: font.xs, color: colors.blue, fontWeight: '600', marginBottom: 2 },
  subjectName: { fontSize: font.sm, color: colors.textPrimary, fontWeight: '500' },
  subjectRight: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs },
  creditsTag: {
    backgroundColor: colors.blueGlow,
    borderRadius: radius.sm,
    paddingHorizontal: spacing.sm,
    paddingVertical: 3,
    borderWidth: 1,
    borderColor: 'rgba(59,130,246,0.2)',
  },
  creditsText: { fontSize: font.xs, color: colors.blueLight, fontWeight: '600' },
  actionsGrid: { gap: spacing.xs },
  actionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bgCard,
    borderRadius: radius.md,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
    gap: spacing.sm,
  },
  actionIcon: {
    width: 36,
    height: 36,
    borderRadius: radius.sm,
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionLabel: { flex: 1, fontSize: font.sm, fontWeight: '600', color: colors.textPrimary },
  profileBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    backgroundColor: colors.bgCard,
    borderRadius: radius.md,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
    marginBottom: spacing.md,
  },
  profileBtnText: { flex: 1, fontSize: font.sm, color: colors.textSecondary, fontWeight: '500' },
  // Notifications drawer
  backdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.55)',
    zIndex: 10,
  },
  notifDrawer: {
    position: 'absolute',
    top: 0,
    right: 0,
    bottom: 0,
    width: '82%',
    backgroundColor: colors.bgCard,
    borderLeftWidth: 1,
    borderLeftColor: colors.border,
    zIndex: 11,
  },
  notifHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  notifTitle: { fontSize: font.lg, fontWeight: '700', color: colors.textPrimary },
  notifClose: { padding: spacing.xs },
  notifScroll: { padding: spacing.md, gap: spacing.sm },
  notifCard: {
    flexDirection: 'row',
    gap: spacing.md,
    backgroundColor: colors.bgElevated,
    borderRadius: radius.md,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  notifIcon: {
    width: 40,
    height: 40,
    borderRadius: radius.sm,
    alignItems: 'center',
    justifyContent: 'center',
  },
  notifBody: { flex: 1 },
  notifItemTitle: { fontSize: font.sm, fontWeight: '700', color: colors.textPrimary, marginBottom: 2 },
  notifItemBody: { fontSize: font.xs, color: colors.textSecondary, lineHeight: 18, marginBottom: 6 },
  notifTimeRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  notifTime: { fontSize: font.xs, color: colors.textMuted },
});
