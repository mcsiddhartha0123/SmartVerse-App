import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Linking,
  Modal,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import {
  Briefcase,
  MapPin,
  Clock,
  IndianRupee,
  Crown,
  ExternalLink,
  X,
  Calendar,
  ChevronRight,
  Bookmark,
  CheckCircle,
  Filter,
} from 'lucide-react-native';
import { router } from 'expo-router';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { colors, spacing, radius, font } from '@/constants/theme';

interface Internship {
  id: string;
  company: string;
  role: string;
  location: string;
  stipend: string | null;
  duration: string | null;
  skills: string[];
  apply_url: string | null;
  deadline: string | null;
  is_premium_only: boolean;
  posted_at: string;
}

interface Application {
  id: string;
  internship_id: string;
  status: 'saved' | 'applied';
  created_at: string;
}

const LOCAL_INTERNSHIPS: Internship[] = [
  {
    id: '1',
    company: 'Texas Instruments',
    role: 'VLSI Design Intern',
    location: 'Bengaluru',
    stipend: '₹40,000/mo',
    duration: '6 months',
    skills: ['VLSI', 'Verilog', 'CMOS', 'Cadence'],
    apply_url: 'https://careers.ti.com',
    deadline: '2026-07-31',
    is_premium_only: false,
    posted_at: new Date().toISOString(),
  },
  {
    id: '2',
    company: 'Qualcomm',
    role: 'Embedded Systems Intern',
    location: 'Hyderabad',
    stipend: '₹50,000/mo',
    duration: '3 months',
    skills: ['C', 'RTOS', 'ARM', 'Linux'],
    apply_url: 'https://careers.qualcomm.com',
    deadline: '2026-07-15',
    is_premium_only: false,
    posted_at: new Date().toISOString(),
  },
  {
    id: '3',
    company: 'Samsung R&D',
    role: 'Signal Processing Intern',
    location: 'Bengaluru',
    stipend: '₹35,000/mo',
    duration: '6 months',
    skills: ['DSP', 'MATLAB', 'Python', 'FPGA'],
    apply_url: 'https://research.samsung.com/careers',
    deadline: '2026-08-01',
    is_premium_only: true,
    posted_at: new Date().toISOString(),
  },
  {
    id: '4',
    company: 'Intel',
    role: 'Hardware Engineer Intern',
    location: 'Bengaluru',
    stipend: '₹60,000/mo',
    duration: '4 months',
    skills: ['PCB Design', 'FPGA', 'Verilog', 'Altium'],
    apply_url: 'https://jobs.intel.com',
    deadline: '2026-07-20',
    is_premium_only: true,
    posted_at: new Date().toISOString(),
  },
  {
    id: '5',
    company: 'ISRO',
    role: 'Electronics Intern',
    location: 'Ahmedabad',
    stipend: '₹15,000/mo',
    duration: '2 months',
    skills: ['RF', 'Antenna Design', 'PCB', 'Simulation'],
    apply_url: 'https://isro.gov.in/careers',
    deadline: '2026-06-30',
    is_premium_only: false,
    posted_at: new Date().toISOString(),
  },
  {
    id: '6',
    company: 'Bosch',
    role: 'Automotive Electronics Intern',
    location: 'Pune',
    stipend: '₹30,000/mo',
    duration: '6 months',
    skills: ['CAN Bus', 'Embedded C', 'Autosar', 'MATLAB'],
    apply_url: 'https://bosch.com/careers',
    deadline: '2026-08-15',
    is_premium_only: false,
    posted_at: new Date().toISOString(),
  },
];

function daysLeft(deadline: string) {
  const diff = new Date(deadline).getTime() - Date.now();
  const days = Math.ceil(diff / 86400000);
  if (days < 0) return 'Closed';
  if (days === 0) return 'Today!';
  return `${days}d left`;
}

function deadlineColor(deadline: string) {
  const diff = new Date(deadline).getTime() - Date.now();
  const days = Math.ceil(diff / 86400000);
  if (days < 0) return colors.textMuted;
  if (days <= 5) return colors.error;
  if (days <= 14) return colors.warning;
  return colors.success;
}

const COMPANY_COLORS: Record<string, [string, string]> = {
  'Texas Instruments': ['#1A3A2A', '#0F2418'],
  'Qualcomm': ['#1E1A3A', '#0F0E2A'],
  'Samsung R&D': ['#1A2A3A', '#0F1A2A'],
  'Intel': ['#3A2A1A', '#2A1A0F'],
  'ISRO': ['#1A2A1A', '#0F1F0F'],
  'Bosch': ['#2A1A1A', '#1A0F0F'],
};

export default function InternshipsScreen() {
  const { user } = useAuth();
  const [internships, setInternships] = useState<Internship[]>(LOCAL_INTERNSHIPS);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState<'all' | 'free' | 'premium' | 'saved'>('all');
  const [isPremium, setIsPremium] = useState(false);
  const [selected, setSelected] = useState<Internship | null>(null);
  const [savedIds, setSavedIds] = useState<Set<string>>(new Set());
  const [appliedIds, setAppliedIds] = useState<Set<string>>(new Set());
  const [togglingId, setTogglingId] = useState<string | null>(null);

  useEffect(() => {
    loadData();
  }, [user]);

  const loadData = async () => {
    if (!user) return;
    setLoading(true);
    const [internRes, profileRes, savedRes] = await Promise.all([
      supabase.from('internships').select('*').order('posted_at', { ascending: false }),
      supabase.from('profiles').select('is_premium').eq('id', user.id).maybeSingle(),
      supabase.from('saved_internships').select('internship_id, status').eq('user_id', user.id),
    ]);
    if (internRes.data && internRes.data.length > 0) setInternships(internRes.data);
    if (profileRes.data) setIsPremium(profileRes.data.is_premium);
    if (savedRes.data) {
      const saved = new Set<string>();
      const applied = new Set<string>();
      savedRes.data.forEach((s: any) => {
        if (s.status === 'saved') saved.add(s.internship_id);
        if (s.status === 'applied') applied.add(s.internship_id);
      });
      setSavedIds(saved);
      setAppliedIds(applied);
    }
    setLoading(false);
  };

  const toggleSaved = async (internId: string) => {
    if (!user || !isPremium) {
      router.push('/(tabs)/premium');
      return;
    }
    setTogglingId(internId);
    const isSaved = savedIds.has(internId);
    if (isSaved) {
      await supabase.from('saved_internships').delete().eq('user_id', user.id).eq('internship_id', internId);
      setSavedIds(prev => { const next = new Set(prev); next.delete(internId); return next; });
    } else {
      await supabase.from('saved_internships').insert({ user_id: user.id, internship_id: internId, status: 'saved' });
      setSavedIds(prev => prev.add(internId));
    }
    setTogglingId(null);
  };

  const markApplied = async (internId: string) => {
    if (!user || !isPremium) {
      router.push('/(tabs)/premium');
      return;
    }
    setTogglingId(internId);
    await supabase.from('saved_internships').upsert(
      { user_id: user.id, internship_id: internId, status: 'applied' },
      { onConflict: 'user_id,internship_id' }
    );
    setAppliedIds(prev => prev.add(internId));
    setSavedIds(prev => prev.delete(internId));
    setTogglingId(null);
  };

  const handleApply = (intern: Internship) => {
    if (intern.apply_url) {
      if (isPremium) markApplied(intern.id);
      Linking.openURL(intern.apply_url).catch(() => setSelected(intern));
    } else {
      setSelected(intern);
    }
  };

  const filtered = internships.filter((i) => {
    if (filter === 'free') return !i.is_premium_only;
    if (filter === 'premium') return i.is_premium_only;
    if (filter === 'saved') return savedIds.has(i.id) || appliedIds.has(i.id);
    return true;
  });

  const savedCount = savedIds.size + appliedIds.size;

  return (
    <View style={styles.container}>
      <SafeAreaView edges={['top']} style={styles.safeArea}>
        <View style={styles.header}>
          <Text style={styles.pageTitle}>Internships</Text>
          <Text style={styles.pageSubtitle}>{internships.length} opportunities for ECE</Text>
          {isPremium && savedCount > 0 && (
            <TouchableOpacity
              style={styles.savedCountBadge}
              onPress={() => setFilter(filter === 'saved' ? 'all' : 'saved')}
            >
              <Bookmark size={12} color={colors.blue} strokeWidth={2} />
              <Text style={styles.savedCountText}>{savedCount}</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Filter Tabs */}
        <View style={styles.filterRow}>
          {(['all', 'free', 'premium'] as const).map((f) => (
            <TouchableOpacity
              key={f}
              style={[styles.filterTab, filter === f && styles.filterTabActive]}
              onPress={() => setFilter(f)}
              activeOpacity={0.8}
            >
              {f === 'premium' && (
                <Crown
                  size={12}
                  color={filter === 'premium' ? colors.premium : colors.textMuted}
                  strokeWidth={2}
                />
              )}
              <Text style={[styles.filterTabText, filter === f && styles.filterTabTextActive]}>
                {f.charAt(0).toUpperCase() + f.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
          {isPremium && (
            <TouchableOpacity
              style={[styles.filterTab, filter === 'saved' && styles.filterTabActive]}
              onPress={() => setFilter('saved')}
              activeOpacity={0.8}
            >
              <Bookmark size={12} color={filter === 'saved' ? colors.blue : colors.textMuted} strokeWidth={2} />
              <Text style={[styles.filterTabText, filter === 'saved' && styles.filterTabTextActive]}>
                Saved ({savedCount})
              </Text>
            </TouchableOpacity>
          )}
        </View>

        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
          {loading ? (
            <ActivityIndicator color={colors.blue} style={{ marginTop: 40 }} />
          ) : filtered.length === 0 ? (
            <View style={styles.emptyState}>
              <Briefcase size={48} color={colors.border} strokeWidth={1} />
              <Text style={styles.emptyTitle}>No listings found</Text>
            </View>
          ) : (
            filtered.map((intern) => {
              const isLocked = intern.is_premium_only && !isPremium;
              const isSaved = savedIds.has(intern.id);
              const isApplied = appliedIds.has(intern.id);
              const gradColors = COMPANY_COLORS[intern.company] ?? ['#1A2235', '#111827'];

              return (
                <TouchableOpacity
                  key={intern.id}
                  style={[styles.card, isLocked && styles.cardLocked]}
                  onPress={() => isLocked ? router.push('/(tabs)/premium') : setSelected(intern)}
                  activeOpacity={0.85}
                >
                  <LinearGradient
                    colors={gradColors}
                    style={styles.cardGrad}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                  >
                    <View style={styles.cardHeader}>
                      <View style={styles.companyInfo}>
                        <View style={styles.companyLogo}>
                          <Text style={styles.companyInitial}>{intern.company[0]}</Text>
                        </View>
                        <View style={{ flex: 1 }}>
                          <Text style={styles.companyName}>{intern.company}</Text>
                          <Text style={styles.roleText}>{intern.role}</Text>
                        </View>
                      </View>
                      {intern.is_premium_only ? (
                        <View style={styles.premiumTag}>
                          <Crown size={12} color={colors.premium} strokeWidth={2} />
                          <Text style={styles.premiumTagText}>PRO</Text>
                        </View>
                      ) : (
                        <View style={styles.freeTag}>
                          <Text style={styles.freeTagText}>FREE</Text>
                        </View>
                      )}
                    </View>

                    {isLocked ? (
                      <View style={styles.lockedOverlay}>
                        <Crown size={28} color={colors.premium} strokeWidth={1.5} />
                        <Text style={styles.lockedText}>Premium Only</Text>
                        <View style={styles.unlockBtn}>
                          <Text style={styles.unlockBtnText}>Unlock with Pro</Text>
                          <ChevronRight size={14} color={colors.premium} strokeWidth={2} />
                        </View>
                      </View>
                    ) : (
                      <>
                        <View style={styles.metaRow}>
                          <View style={styles.metaItem}>
                            <MapPin size={13} color={colors.textMuted} strokeWidth={1.5} />
                            <Text style={styles.metaText}>{intern.location}</Text>
                          </View>
                          {intern.duration && (
                            <View style={styles.metaItem}>
                              <Clock size={13} color={colors.textMuted} strokeWidth={1.5} />
                              <Text style={styles.metaText}>{intern.duration}</Text>
                            </View>
                          )}
                          {intern.stipend && (
                            <View style={styles.metaItem}>
                              <IndianRupee size={13} color={colors.success} strokeWidth={1.5} />
                              <Text style={[styles.metaText, { color: colors.success }]}>
                                {intern.stipend}
                              </Text>
                            </View>
                          )}
                        </View>

                        <View style={styles.skillsRow}>
                          {intern.skills.slice(0, 3).map((skill) => (
                            <View key={skill} style={styles.skillTag}>
                              <Text style={styles.skillText}>{skill}</Text>
                            </View>
                          ))}
                          {intern.skills.length > 3 && (
                            <View style={styles.skillTag}>
                              <Text style={styles.skillText}>+{intern.skills.length - 3}</Text>
                            </View>
                          )}
                        </View>

                        <View style={styles.cardFooter}>
                          <View style={styles.footerLeft}>
                            {intern.deadline && (
                              <View style={styles.deadlineWrap}>
                                <Calendar size={12} color={deadlineColor(intern.deadline)} strokeWidth={1.5} />
                                <Text style={[styles.deadline, { color: deadlineColor(intern.deadline) }]}>
                                  {daysLeft(intern.deadline)}
                                </Text>
                              </View>
                            )}
                            {isApplied && (
                              <View style={styles.appliedBadge}>
                                <CheckCircle size={12} color={colors.success} strokeWidth={2} />
                                <Text style={styles.appliedText}>Applied</Text>
                              </View>
                            )}
                          </View>
                          <View style={styles.footerActions}>
                            <TouchableOpacity
                              style={[styles.saveBtn, isSaved && styles.saveBtnActive]}
                              onPress={() => toggleSaved(intern.id)}
                              disabled={togglingId === intern.id}
                            >
                              <Bookmark
                                size={16}
                                color={isSaved ? colors.blue : colors.textMuted}
                                strokeWidth={2}
                                fill={isSaved ? colors.blue : 'transparent'}
                              />
                            </TouchableOpacity>
                            <TouchableOpacity
                              style={styles.applyBtn}
                              onPress={() => handleApply(intern)}
                              activeOpacity={0.85}
                            >
                              <LinearGradient
                                colors={[colors.blue, colors.blueDark]}
                                start={{ x: 0, y: 0 }}
                                end={{ x: 1, y: 0 }}
                                style={styles.applyBtnGrad}
                              >
                                <Text style={styles.applyBtnText}>Apply</Text>
                                <ExternalLink size={13} color="#fff" strokeWidth={2} />
                              </LinearGradient>
                            </TouchableOpacity>
                          </View>
                        </View>
                      </>
                    )}
                  </LinearGradient>
                </TouchableOpacity>
              );
            })
          )}
          <View style={{ height: 80 }} />
        </ScrollView>
      </SafeAreaView>

      {/* Detail Modal */}
      <Modal visible={!!selected} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            {selected && (
              <>
                <View style={styles.modalHeader}>
                  <View style={styles.modalCompanyRow}>
                    <View style={styles.modalLogo}>
                      <Text style={styles.modalLogoText}>{selected.company[0]}</Text>
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.modalCompany}>{selected.company}</Text>
                      <Text style={styles.modalRole}>{selected.role}</Text>
                    </View>
                  </View>
                  <TouchableOpacity onPress={() => setSelected(null)} style={styles.modalClose}>
                    <X size={20} color={colors.textSecondary} strokeWidth={1.5} />
                  </TouchableOpacity>
                </View>

                <ScrollView showsVerticalScrollIndicator={false}>
                  <View style={styles.modalSection}>
                    <View style={styles.modalMetaGrid}>
                      {[
                        { label: 'Location', value: selected.location, icon: MapPin },
                        { label: 'Duration', value: selected.duration ?? 'N/A', icon: Clock },
                        { label: 'Stipend', value: selected.stipend ?? 'Unpaid', icon: IndianRupee },
                        {
                          label: 'Deadline',
                          value: selected.deadline
                            ? new Date(selected.deadline).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })
                            : 'Open',
                          icon: Calendar,
                        },
                      ].map((item) => (
                        <View key={item.label} style={styles.modalMetaItem}>
                          <item.icon size={16} color={colors.blue} strokeWidth={1.5} />
                          <View>
                            <Text style={styles.modalMetaLabel}>{item.label}</Text>
                            <Text style={styles.modalMetaValue}>{item.value}</Text>
                          </View>
                        </View>
                      ))}
                    </View>
                  </View>

                  <View style={styles.modalSection}>
                    <Text style={styles.modalSectionTitle}>Skills Required</Text>
                    <View style={styles.modalSkillsRow}>
                      {selected.skills.map((s) => (
                        <View key={s} style={styles.modalSkillTag}>
                          <Text style={styles.modalSkillText}>{s}</Text>
                        </View>
                      ))}
                    </View>
                  </View>

                  {selected.deadline && (
                    <View style={[styles.deadlineBanner, { borderColor: deadlineColor(selected.deadline) + '55' }]}>
                      <Calendar size={16} color={deadlineColor(selected.deadline)} strokeWidth={1.5} />
                      <Text style={[styles.deadlineBannerText, { color: deadlineColor(selected.deadline) }]}>
                        Application closes: {daysLeft(selected.deadline)}
                      </Text>
                    </View>
                  )}
                </ScrollView>

                <TouchableOpacity
                  style={styles.modalApplyBtn}
                  onPress={() => {
                    setSelected(null);
                    if (selected.apply_url) {
                      handleApply(selected);
                    }
                  }}
                  activeOpacity={0.85}
                >
                  <LinearGradient
                    colors={[colors.blue, colors.blueDark]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                    style={styles.modalApplyGrad}
                  >
                    <ExternalLink size={18} color="#fff" strokeWidth={1.5} />
                    <Text style={styles.modalApplyText}>
                      {selected.apply_url ? 'Apply Now' : 'Check Company Website'}
                    </Text>
                  </LinearGradient>
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  safeArea: { flex: 1 },
  header: { paddingHorizontal: spacing.md, paddingVertical: spacing.md },
  pageTitle: { fontSize: font.xxl, fontWeight: '800', color: colors.textPrimary },
  pageSubtitle: { fontSize: font.sm, color: colors.textSecondary, marginTop: 2 },
  savedCountBadge: {
    position: 'absolute',
    right: spacing.md,
    top: spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: colors.blueGlow,
    borderRadius: radius.full,
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderWidth: 1,
    borderColor: 'rgba(59,130,246,0.3)',
  },
  savedCountText: { fontSize: font.xs, color: colors.blue, fontWeight: '700' },
  filterRow: { flexDirection: 'row', paddingHorizontal: spacing.md, gap: spacing.xs, marginBottom: spacing.sm },
  filterTab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
    paddingVertical: spacing.sm,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.bgCard,
  },
  filterTabActive: { borderColor: colors.blue, backgroundColor: colors.blueGlow },
  filterTabText: { fontSize: font.sm, color: colors.textSecondary, fontWeight: '600' },
  filterTabTextActive: { color: colors.blue },
  scroll: { paddingHorizontal: spacing.md },
  emptyState: { alignItems: 'center', paddingTop: 60, gap: spacing.sm },
  emptyTitle: { fontSize: font.lg, fontWeight: '600', color: colors.textSecondary },
  card: {
    borderRadius: radius.xl,
    overflow: 'hidden',
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  cardLocked: { borderColor: 'rgba(245,158,11,0.25)' },
  cardGrad: { padding: spacing.md },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: spacing.md,
  },
  companyInfo: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, flex: 1 },
  companyLogo: {
    width: 44,
    height: 44,
    borderRadius: radius.md,
    backgroundColor: 'rgba(255,255,255,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  companyInitial: { fontSize: font.xl, fontWeight: '800', color: '#fff' },
  companyName: { fontSize: font.sm, fontWeight: '700', color: colors.textPrimary },
  roleText: { fontSize: font.sm, color: colors.textSecondary, marginTop: 2 },
  premiumTag: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: colors.premiumBg,
    borderRadius: radius.full,
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderWidth: 1,
    borderColor: 'rgba(245,158,11,0.3)',
  },
  premiumTagText: { fontSize: font.xs, color: colors.premium, fontWeight: '700' },
  freeTag: {
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderRadius: radius.full,
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.3)',
  },
  freeTagText: { fontSize: font.xs, color: colors.success, fontWeight: '700' },
  metaRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.md, marginBottom: spacing.sm },
  metaItem: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  metaText: { fontSize: font.sm, color: colors.textSecondary },
  skillsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs, marginBottom: spacing.md },
  skillTag: {
    backgroundColor: 'rgba(59,130,246,0.12)',
    borderRadius: radius.sm,
    paddingHorizontal: spacing.sm,
    paddingVertical: 3,
    borderWidth: 1,
    borderColor: 'rgba(59,130,246,0.2)',
  },
  skillText: { fontSize: font.xs, color: colors.blueLight, fontWeight: '600' },
  cardFooter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  footerLeft: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  deadlineWrap: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  deadline: { fontSize: font.sm, fontWeight: '700' },
  appliedBadge: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  appliedText: { fontSize: font.xs, color: colors.success, fontWeight: '600' },
  footerActions: { flexDirection: 'row', gap: spacing.xs },
  saveBtn: {
    width: 38,
    height: 38,
    borderRadius: radius.sm,
    backgroundColor: colors.bgElevated,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  saveBtnActive: { borderColor: colors.blue, backgroundColor: colors.blueGlow },
  applyBtn: { borderRadius: radius.md, overflow: 'hidden' },
  applyBtnGrad: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },
  applyBtnText: { color: '#fff', fontSize: font.sm, fontWeight: '700' },
  lockedOverlay: { alignItems: 'center', paddingVertical: spacing.md, gap: spacing.xs },
  lockedText: { fontSize: font.md, fontWeight: '700', color: colors.premium },
  unlockBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: spacing.xs,
    borderRadius: radius.full,
    borderWidth: 1,
    borderColor: 'rgba(245,158,11,0.4)',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    backgroundColor: colors.premiumBg,
  },
  unlockBtnText: { fontSize: font.xs, color: colors.premium, fontWeight: '700' },
  // Modal
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'flex-end' },
  modalCard: {
    backgroundColor: colors.bgCard,
    borderTopLeftRadius: radius.xl,
    borderTopRightRadius: radius.xl,
    padding: spacing.lg,
    maxHeight: '85%',
    borderTopWidth: 1,
    borderColor: colors.border,
  },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: spacing.lg },
  modalCompanyRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, flex: 1 },
  modalLogo: {
    width: 52,
    height: 52,
    borderRadius: radius.md,
    backgroundColor: colors.blueGlow,
    borderWidth: 1,
    borderColor: 'rgba(59,130,246,0.3)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalLogoText: { fontSize: font.xxl, fontWeight: '800', color: colors.blue },
  modalCompany: { fontSize: font.sm, fontWeight: '700', color: colors.textSecondary },
  modalRole: { fontSize: font.lg, fontWeight: '800', color: colors.textPrimary, marginTop: 2 },
  modalClose: { padding: spacing.xs },
  modalSection: { marginBottom: spacing.lg },
  modalMetaGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  modalMetaItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.sm,
    backgroundColor: colors.bgElevated,
    borderRadius: radius.md,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
    width: '47%',
  },
  modalMetaLabel: { fontSize: font.xs, color: colors.textMuted, fontWeight: '600', marginBottom: 2 },
  modalMetaValue: { fontSize: font.sm, color: colors.textPrimary, fontWeight: '600' },
  modalSectionTitle: {
    fontSize: font.sm,
    fontWeight: '700',
    color: colors.textSecondary,
    marginBottom: spacing.sm,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  modalSkillsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs },
  modalSkillTag: {
    backgroundColor: colors.blueGlow,
    borderRadius: radius.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderWidth: 1,
    borderColor: 'rgba(59,130,246,0.25)',
  },
  modalSkillText: { fontSize: font.sm, color: colors.blueLight, fontWeight: '600' },
  deadlineBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderRadius: radius.md,
    padding: spacing.md,
    borderWidth: 1,
    backgroundColor: colors.bgElevated,
    marginBottom: spacing.md,
  },
  deadlineBannerText: { fontSize: font.sm, fontWeight: '700' },
  modalApplyBtn: { borderRadius: radius.md, overflow: 'hidden', marginTop: spacing.sm },
  modalApplyGrad: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    height: 56,
  },
  modalApplyText: { color: '#fff', fontSize: font.lg, fontWeight: '700' },
});
