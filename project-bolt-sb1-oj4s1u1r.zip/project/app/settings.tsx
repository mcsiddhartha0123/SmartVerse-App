import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import {
  ChevronLeft,
  Bell,
  Moon,
  Globe,
  Shield,
  HelpCircle,
  Mail,
  Info,
  ChevronRight,
  Trash2,
  Crown,
} from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { colors, spacing, radius, font } from '@/constants/theme';

export default function SettingsScreen() {
  const { user, signOut } = useAuth();
  const [isPremium, setIsPremium] = useState(false);
  const [loading, setLoading] = useState(true);
  const [notifications, setNotifications] = useState(true);
  const [darkMode, setDarkMode] = useState(true);

  useEffect(() => {
    loadProfile();
  }, [user]);

  const loadProfile = async () => {
    if (!user) return;
    setLoading(true);
    const { data } = await supabase
      .from('profiles')
      .select('is_premium')
      .eq('id', user.id)
      .maybeSingle();
    if (data) setIsPremium(data.is_premium);
    setLoading(false);
  };

  const handleClearData = () => {
    Alert.alert(
      'Clear All Data',
      'This will delete all your notes, CGPA records, and application history. This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Clear',
          style: 'destructive',
          onPress: async () => {
            if (!user) return;
            await Promise.all([
              supabase.from('notes').delete().eq('user_id', user.id),
              supabase.from('cgpa_records').delete().eq('user_id', user.id),
              supabase.from('subscriptions').delete().eq('user_id', user.id),
            ]);
            Alert.alert('Done', 'All your data has been cleared.');
          },
        },
      ]
    );
  };

  const handleDeleteAccount = () => {
    Alert.alert(
      'Delete Account',
      'This will permanently delete your account and all associated data. This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            if (!user) return;
            await supabase.from('profiles').delete().eq('id', user.id);
            await signOut();
            router.replace('/auth/login');
          },
        },
      ]
    );
  };

  if (loading) {
    return (
      <View style={styles.loadingWrap}>
        <ActivityIndicator color={colors.blue} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <SafeAreaView edges={['top']} style={styles.safeArea}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn} activeOpacity={0.7}>
            <ChevronLeft size={24} color={colors.textPrimary} strokeWidth={2} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Settings</Text>
          <View style={{ width: 40 }} />
        </View>

        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
          {/* Premium Banner */}
          {!isPremium && (
            <TouchableOpacity
              style={styles.premiumBanner}
              onPress={() => router.push('/(tabs)/premium')}
              activeOpacity={0.85}
            >
              <LinearGradient
                colors={['rgba(245,158,11,0.15)', 'rgba(245,158,11,0.05)']}
                style={styles.premiumBannerGrad}
              >
                <Crown size={24} color={colors.premium} strokeWidth={1.5} />
                <View style={styles.premiumBannerText}>
                  <Text style={styles.premiumBannerTitle}>Upgrade to Pro</Text>
                  <Text style={styles.premiumBannerSubtitle}>Unlock all features and premium content</Text>
                </View>
                <ChevronRight size={18} color={colors.premium} strokeWidth={2} />
              </LinearGradient>
            </TouchableOpacity>
          )}

          {/* Preferences */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Preferences</Text>

            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <View style={[styles.settingIcon, { backgroundColor: colors.blueGlow }]}>
                  <Bell size={18} color={colors.blue} strokeWidth={1.5} />
                </View>
                <View>
                  <Text style={styles.settingLabel}>Push Notifications</Text>
                  <Text style={styles.settingHint}>Deadlines & reminders</Text>
                </View>
              </View>
              <Switch
                value={notifications}
                onValueChange={setNotifications}
                trackColor={{ false: colors.border, true: colors.blue }}
                thumbColor={notifications ? '#fff' : colors.textMuted}
              />
            </View>

            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <View style={[styles.settingIcon, { backgroundColor: 'rgba(139,92,246,0.15)' }]}>
                  <Moon size={18} color="#8B5CF6" strokeWidth={1.5} />
                </View>
                <View>
                  <Text style={styles.settingLabel}>Dark Mode</Text>
                  <Text style={styles.settingHint}>Always enabled</Text>
                </View>
              </View>
              <Switch
                value={darkMode}
                onValueChange={setDarkMode}
                trackColor={{ false: colors.border, true: colors.blue }}
                thumbColor="#fff"
                disabled
              />
            </View>
          </View>

          {/* Support */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Support</Text>

            <TouchableOpacity style={styles.linkItem} activeOpacity={0.8}>
              <View style={styles.linkLeft}>
                <HelpCircle size={18} color={colors.textSecondary} strokeWidth={1.5} />
                <Text style={styles.linkLabel}>Help Center</Text>
              </View>
              <ChevronRight size={16} color={colors.textMuted} strokeWidth={2} />
            </TouchableOpacity>

            <TouchableOpacity style={styles.linkItem} activeOpacity={0.8}>
              <View style={styles.linkLeft}>
                <Mail size={18} color={colors.textSecondary} strokeWidth={1.5} />
                <Text style={styles.linkLabel}>Contact Us</Text>
              </View>
              <ChevronRight size={16} color={colors.textMuted} strokeWidth={2} />
            </TouchableOpacity>

            <TouchableOpacity style={styles.linkItem} activeOpacity={0.8}>
              <View style={styles.linkLeft}>
                <Shield size={18} color={colors.textSecondary} strokeWidth={1.5} />
                <Text style={styles.linkLabel}>Privacy Policy</Text>
              </View>
              <ChevronRight size={16} color={colors.textMuted} strokeWidth={2} />
            </TouchableOpacity>

            <TouchableOpacity style={styles.linkItem} activeOpacity={0.8}>
              <View style={styles.linkLeft}>
                <Info size={18} color={colors.textSecondary} strokeWidth={1.5} />
                <Text style={styles.linkLabel}>About ECEHub</Text>
              </View>
              <ChevronRight size={16} color={colors.textMuted} strokeWidth={2} />
            </TouchableOpacity>
          </View>

          {/* Danger Zone */}
          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: colors.error }]}>Danger Zone</Text>

            <TouchableOpacity style={styles.dangerItem} onPress={handleClearData} activeOpacity={0.8}>
              <Trash2 size={18} color={colors.error} strokeWidth={1.5} />
              <Text style={styles.dangerLabel}>Clear All Data</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.dangerItem} onPress={handleDeleteAccount} activeOpacity={0.8}>
              <Trash2 size={18} color={colors.error} strokeWidth={1.5} />
              <Text style={styles.dangerLabel}>Delete Account</Text>
            </TouchableOpacity>
          </View>

          <Text style={styles.version}>ECEHub v1.0.0</Text>
          <View style={{ height: 80 }} />
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  safeArea: { flex: 1 },
  loadingWrap: { flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },
  backBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontSize: font.lg, fontWeight: '700', color: colors.textPrimary },
  scroll: { paddingHorizontal: spacing.md, paddingTop: spacing.sm },
  premiumBanner: {
    marginBottom: spacing.lg,
    borderRadius: radius.lg,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(245,158,11,0.2)',
  },
  premiumBannerGrad: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: spacing.md,
    gap: spacing.md,
  },
  premiumBannerText: { flex: 1 },
  premiumBannerTitle: { fontSize: font.md, fontWeight: '700', color: colors.premium },
  premiumBannerSubtitle: { fontSize: font.xs, color: colors.textSecondary, marginTop: 2 },
  section: { marginBottom: spacing.lg },
  sectionTitle: {
    fontSize: font.xs,
    fontWeight: '700',
    color: colors.textMuted,
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: spacing.sm,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.bgCard,
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.xs,
    borderWidth: 1,
    borderColor: colors.border,
  },
  settingLeft: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, flex: 1 },
  settingIcon: {
    width: 36,
    height: 36,
    borderRadius: radius.sm,
    alignItems: 'center',
    justifyContent: 'center',
  },
  settingLabel: { fontSize: font.sm, fontWeight: '600', color: colors.textPrimary },
  settingHint: { fontSize: font.xs, color: colors.textMuted, marginTop: 2 },
  linkItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.bgCard,
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.xs,
    borderWidth: 1,
    borderColor: colors.border,
  },
  linkLeft: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  linkLabel: { fontSize: font.sm, color: colors.textPrimary },
  dangerItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    backgroundColor: 'rgba(239,68,68,0.08)',
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.xs,
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.2)',
  },
  dangerLabel: { fontSize: font.sm, color: colors.error, fontWeight: '500' },
  version: {
    textAlign: 'center',
    color: colors.textMuted,
    fontSize: font.xs,
    marginTop: spacing.lg,
  },
});
