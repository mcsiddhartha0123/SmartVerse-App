import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import {
  Crown,
  Check,
  Zap,
  BookOpen,
  Briefcase,
  TrendingUp,
  Bell,
  Download,
  Star,
  Shield,
} from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { colors, spacing, radius, font } from '@/constants/theme';

const FREE_FEATURES = [
  { icon: BookOpen, label: 'Up to 10 notes' },
  { icon: TrendingUp, label: 'Basic CGPA calculator' },
  { icon: Briefcase, label: '3 internship listings' },
];

const PRO_FEATURES = [
  { icon: BookOpen, label: 'Unlimited notes + attachments', highlight: false },
  { icon: TrendingUp, label: 'CGPA history & analytics', highlight: false },
  { icon: Briefcase, label: 'All internship listings (premium companies)', highlight: true },
  { icon: Bell, label: 'Deadline reminders & push notifications', highlight: false },
  { icon: Download, label: 'Download notes as PDF', highlight: false },
  { icon: Star, label: 'Priority support', highlight: false },
  { icon: Shield, label: 'Ad-free experience', highlight: false },
  { icon: Zap, label: 'Early access to new features', highlight: true },
];

const PLANS = [
  {
    id: 'monthly',
    name: 'Monthly',
    price: '₹199',
    period: '/month',
    badge: null,
    savings: null,
  },
  {
    id: 'semester',
    name: 'Semester',
    price: '₹499',
    period: '/6 months',
    badge: 'POPULAR',
    savings: 'Save 58%',
  },
  {
    id: 'annual',
    name: 'Annual',
    price: '₹799',
    period: '/year',
    badge: 'BEST VALUE',
    savings: 'Save 67%',
  },
];

const TESTIMONIALS = [
  { name: 'Priya K.', text: 'Got my TI internship through the premium listings. Best ₹499 I spent!', rating: 5 },
  { name: 'Arjun M.', text: 'The CGPA analytics helped me plan my 8th semester strategy perfectly.', rating: 5 },
  { name: 'Sneha R.', text: 'Notes + PDF export is a lifesaver during exam season.', rating: 5 },
];

export default function PremiumScreen() {
  const { user } = useAuth();
  const [selectedPlan, setSelectedPlan] = useState('semester');
  const [loading, setLoading] = useState(false);
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = async () => {
    if (!user) return;
    setLoading(true);
    const plan = PLANS.find(p => p.id === selectedPlan)!;

    const expiresAt = new Date();
    if (selectedPlan === 'monthly') expiresAt.setMonth(expiresAt.getMonth() + 1);
    else if (selectedPlan === 'semester') expiresAt.setMonth(expiresAt.getMonth() + 6);
    else expiresAt.setFullYear(expiresAt.getFullYear() + 1);

    await Promise.all([
      supabase.from('subscriptions').insert({
        plan: selectedPlan,
        status: 'active',
        expires_at: expiresAt.toISOString(),
      }),
      supabase.from('profiles').update({ is_premium: true }).eq('id', user.id),
    ]);

    setLoading(false);
    setSubscribed(true);
  };

  if (subscribed) {
    return (
      <View style={styles.container}>
        <SafeAreaView edges={['top']} style={styles.safeArea}>
          <View style={styles.successScreen}>
            <LinearGradient
              colors={['rgba(245,158,11,0.2)', 'rgba(245,158,11,0.05)']}
              style={styles.successGlow}
            />
            <View style={styles.successIcon}>
              <LinearGradient colors={[colors.premium, '#D97706']} style={styles.successIconGrad}>
                <Crown size={40} color="#fff" strokeWidth={1.5} />
              </LinearGradient>
            </View>
            <Text style={styles.successTitle}>You're Premium!</Text>
            <Text style={styles.successSubtitle}>
              Welcome to ECEHub Pro. Enjoy all premium features.
            </Text>
            <View style={styles.successFeatures}>
              {PRO_FEATURES.slice(0, 4).map(f => (
                <View key={f.label} style={styles.successFeature}>
                  <Check size={16} color={colors.success} strokeWidth={2.5} />
                  <Text style={styles.successFeatureText}>{f.label}</Text>
                </View>
              ))}
            </View>
          </View>
        </SafeAreaView>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <SafeAreaView edges={['top']} style={styles.safeArea}>
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
          {/* Hero */}
          <View style={styles.hero}>
            <LinearGradient
              colors={['rgba(245,158,11,0.15)', 'transparent']}
              style={styles.heroGlow}
            />
            <View style={styles.crownWrap}>
              <LinearGradient colors={[colors.premium, '#D97706']} style={styles.crownGrad}>
                <Crown size={36} color="#fff" strokeWidth={1.5} />
              </LinearGradient>
            </View>
            <Text style={styles.heroTitle}>ECEHub Pro</Text>
            <Text style={styles.heroSubtitle}>
              Unlock everything you need to excel in your ECE journey
            </Text>
          </View>

          {/* Free vs Pro comparison */}
          <View style={styles.compareCard}>
            <View style={styles.compareCol}>
              <Text style={styles.compareColTitle}>Free</Text>
              {FREE_FEATURES.map(f => (
                <View key={f.label} style={styles.compareRow}>
                  <f.icon size={14} color={colors.textMuted} strokeWidth={1.5} />
                  <Text style={styles.compareTextFree}>{f.label}</Text>
                </View>
              ))}
            </View>
            <View style={styles.compareDivider} />
            <View style={[styles.compareCol, styles.compareColPro]}>
              <Text style={[styles.compareColTitle, { color: colors.premium }]}>Pro</Text>
              {PRO_FEATURES.slice(0, 3).map(f => (
                <View key={f.label} style={styles.compareRow}>
                  <f.icon size={14} color={colors.premium} strokeWidth={1.5} />
                  <Text style={styles.compareTextPro}>{f.label}</Text>
                </View>
              ))}
            </View>
          </View>

          {/* All Pro Features */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Everything in Pro</Text>
            <View style={styles.featuresGrid}>
              {PRO_FEATURES.map(f => (
                <View key={f.label} style={[styles.featureItem, f.highlight && styles.featureItemHighlight]}>
                  <View style={[styles.featureIcon, f.highlight && styles.featureIconHighlight]}>
                    <f.icon size={18} color={f.highlight ? colors.premium : colors.blue} strokeWidth={1.5} />
                  </View>
                  <Text style={styles.featureLabel}>{f.label}</Text>
                </View>
              ))}
            </View>
          </View>

          {/* Plans */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Choose Your Plan</Text>
            <View style={styles.plansRow}>
              {PLANS.map(plan => (
                <TouchableOpacity
                  key={plan.id}
                  style={[styles.planCard, selectedPlan === plan.id && styles.planCardActive]}
                  onPress={() => setSelectedPlan(plan.id)}
                  activeOpacity={0.85}
                >
                  {plan.badge && (
                    <View style={styles.planBadge}>
                      <Text style={styles.planBadgeText}>{plan.badge}</Text>
                    </View>
                  )}
                  <Text style={styles.planName}>{plan.name}</Text>
                  <Text style={[styles.planPrice, selectedPlan === plan.id && styles.planPriceActive]}>
                    {plan.price}
                  </Text>
                  <Text style={styles.planPeriod}>{plan.period}</Text>
                  {plan.savings && (
                    <View style={styles.savingsTag}>
                      <Text style={styles.savingsText}>{plan.savings}</Text>
                    </View>
                  )}
                  {selectedPlan === plan.id && (
                    <View style={styles.planCheck}>
                      <Check size={14} color="#fff" strokeWidth={2.5} />
                    </View>
                  )}
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* CTA */}
          <TouchableOpacity
            style={[styles.ctaBtn, loading && styles.ctaBtnDisabled]}
            onPress={handleSubscribe}
            disabled={loading}
            activeOpacity={0.85}
          >
            <LinearGradient
              colors={[colors.premium, '#D97706']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.ctaBtnGrad}
            >
              {loading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <>
                  <Crown size={20} color="#fff" strokeWidth={1.5} />
                  <Text style={styles.ctaBtnText}>
                    Start Pro — {PLANS.find(p => p.id === selectedPlan)?.price}
                    {PLANS.find(p => p.id === selectedPlan)?.period}
                  </Text>
                </>
              )}
            </LinearGradient>
          </TouchableOpacity>

          <Text style={styles.ctaNote}>Cancel anytime. No hidden fees.</Text>

          {/* Testimonials */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>What students say</Text>
            {TESTIMONIALS.map(t => (
              <View key={t.name} style={styles.testimonialCard}>
                <View style={styles.testimonialHeader}>
                  <View style={styles.testimonialAvatar}>
                    <Text style={styles.testimonialInitial}>{t.name[0]}</Text>
                  </View>
                  <View>
                    <Text style={styles.testimonialName}>{t.name}</Text>
                    <View style={styles.starsRow}>
                      {Array.from({ length: t.rating }).map((_, i) => (
                        <Star key={i} size={12} color={colors.premium} fill={colors.premium} strokeWidth={0} />
                      ))}
                    </View>
                  </View>
                </View>
                <Text style={styles.testimonialText}>"{t.text}"</Text>
              </View>
            ))}
          </View>

          <View style={{ height: 80 }} />
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  safeArea: { flex: 1 },
  scroll: { paddingHorizontal: spacing.md },
  hero: {
    alignItems: 'center',
    paddingVertical: spacing.xl,
    position: 'relative',
  },
  heroGlow: {
    position: 'absolute',
    top: 0,
    left: -spacing.md,
    right: -spacing.md,
    height: 200,
    borderRadius: radius.xl,
  },
  crownWrap: { marginBottom: spacing.md },
  crownGrad: {
    width: 80,
    height: 80,
    borderRadius: radius.xl,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: colors.premium,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 20,
    elevation: 12,
  },
  heroTitle: { fontSize: font.xxxl, fontWeight: '800', color: colors.textPrimary, marginBottom: spacing.xs },
  heroSubtitle: {
    fontSize: font.md,
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: 22,
    paddingHorizontal: spacing.lg,
  },
  compareCard: {
    flexDirection: 'row',
    backgroundColor: colors.bgCard,
    borderRadius: radius.xl,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
    marginBottom: spacing.lg,
  },
  compareCol: { flex: 1, gap: spacing.sm },
  compareColPro: {},
  compareColTitle: {
    fontSize: font.sm,
    fontWeight: '700',
    color: colors.textSecondary,
    marginBottom: spacing.xs,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  compareRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 6 },
  compareTextFree: { fontSize: font.xs, color: colors.textMuted, flex: 1, lineHeight: 18 },
  compareTextPro: { fontSize: font.xs, color: colors.textSecondary, flex: 1, lineHeight: 18 },
  compareDivider: { width: 1, backgroundColor: colors.border, marginHorizontal: spacing.md },
  section: { marginBottom: spacing.lg },
  sectionTitle: {
    fontSize: font.lg,
    fontWeight: '700',
    color: colors.textPrimary,
    marginBottom: spacing.md,
  },
  featuresGrid: { gap: spacing.xs },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    backgroundColor: colors.bgCard,
    borderRadius: radius.md,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  featureItemHighlight: {
    borderColor: 'rgba(245,158,11,0.3)',
    backgroundColor: colors.premiumBg,
  },
  featureIcon: {
    width: 36,
    height: 36,
    borderRadius: radius.sm,
    backgroundColor: colors.blueGlow,
    alignItems: 'center',
    justifyContent: 'center',
  },
  featureIconHighlight: { backgroundColor: 'rgba(245,158,11,0.15)' },
  featureLabel: { flex: 1, fontSize: font.sm, color: colors.textPrimary, fontWeight: '500' },
  plansRow: { flexDirection: 'row', gap: spacing.sm },
  planCard: {
    flex: 1,
    backgroundColor: colors.bgCard,
    borderRadius: radius.lg,
    padding: spacing.md,
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: colors.border,
    position: 'relative',
    overflow: 'hidden',
  },
  planCardActive: {
    borderColor: colors.premium,
    backgroundColor: colors.premiumBg,
  },
  planBadge: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    backgroundColor: colors.premium,
    paddingVertical: 3,
    alignItems: 'center',
  },
  planBadgeText: { fontSize: 9, fontWeight: '800', color: '#000', letterSpacing: 0.5 },
  planName: { fontSize: font.xs, fontWeight: '700', color: colors.textSecondary, marginTop: 16 },
  planPrice: { fontSize: font.xl, fontWeight: '800', color: colors.textPrimary, marginTop: 4 },
  planPriceActive: { color: colors.premium },
  planPeriod: { fontSize: font.xs, color: colors.textMuted },
  savingsTag: {
    marginTop: 6,
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderRadius: radius.sm,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  savingsText: { fontSize: 10, color: colors.success, fontWeight: '700' },
  planCheck: {
    position: 'absolute',
    top: 16,
    right: spacing.sm,
    width: 20,
    height: 20,
    borderRadius: radius.full,
    backgroundColor: colors.premium,
    alignItems: 'center',
    justifyContent: 'center',
  },
  ctaBtn: { borderRadius: radius.md, overflow: 'hidden', marginBottom: spacing.sm },
  ctaBtnDisabled: { opacity: 0.7 },
  ctaBtnGrad: {
    height: 58,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
  },
  ctaBtnText: { color: '#fff', fontSize: font.md, fontWeight: '800' },
  ctaNote: { textAlign: 'center', color: colors.textMuted, fontSize: font.xs, marginBottom: spacing.xl },
  testimonialCard: {
    backgroundColor: colors.bgCard,
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.sm,
    borderWidth: 1,
    borderColor: colors.border,
  },
  testimonialHeader: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: spacing.sm },
  testimonialAvatar: {
    width: 36,
    height: 36,
    borderRadius: radius.full,
    backgroundColor: colors.blueGlow,
    borderWidth: 1,
    borderColor: 'rgba(59,130,246,0.3)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  testimonialInitial: { fontSize: font.md, fontWeight: '700', color: colors.blue },
  testimonialName: { fontSize: font.sm, fontWeight: '700', color: colors.textPrimary },
  starsRow: { flexDirection: 'row', gap: 2, marginTop: 2 },
  testimonialText: { fontSize: font.sm, color: colors.textSecondary, lineHeight: 20 },
  successScreen: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xl,
    position: 'relative',
  },
  successGlow: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    borderRadius: radius.xl,
  },
  successIcon: { marginBottom: spacing.lg },
  successIconGrad: {
    width: 100,
    height: 100,
    borderRadius: radius.full,
    alignItems: 'center',
    justifyContent: 'center',
  },
  successTitle: { fontSize: font.xxxl, fontWeight: '800', color: colors.textPrimary, marginBottom: spacing.xs },
  successSubtitle: {
    fontSize: font.md,
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: spacing.xl,
  },
  successFeatures: { width: '100%', gap: spacing.sm },
  successFeature: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  successFeatureText: { fontSize: font.sm, color: colors.textPrimary },
});
