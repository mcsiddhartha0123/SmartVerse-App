-- Add saved_internships table for tracking applications (premium feature)
CREATE TABLE IF NOT EXISTS saved_internships (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  internship_id uuid NOT NULL REFERENCES internships(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'saved' CHECK (status IN ('saved', 'applied')),
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, internship_id)
);

ALTER TABLE saved_internships ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_saved" ON saved_internships FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_saved" ON saved_internships FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_saved" ON saved_internships FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_saved" ON saved_internships FOR DELETE TO authenticated USING (auth.uid() = user_id);