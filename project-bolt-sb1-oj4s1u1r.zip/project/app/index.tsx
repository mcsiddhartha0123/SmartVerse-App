import React, { useEffect } from 'react';
import { View, StyleSheet, ActivityIndicator } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Cpu } from 'lucide-react-native';
import { router } from 'expo-router';
import { useAuth } from '@/context/AuthContext';
import { colors, spacing, radius } from '@/constants/theme';

export default function SplashScreen() {
  const { session, loading } = useAuth();

  useEffect(() => {
    if (!loading) {
      if (session) {
        router.replace('/(tabs)');
      } else {
        router.replace('/auth/login');
      }
    }
  }, [session, loading]);

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#0D1629', '#0A0E1A']} style={StyleSheet.absoluteFillObject} />
      <View style={styles.logoWrap}>
        <LinearGradient colors={[colors.blue, colors.blueDark]} style={styles.logoGradient}>
          <Cpu size={48} color="#fff" strokeWidth={1.5} />
        </LinearGradient>
      </View>
      <ActivityIndicator color={colors.blue} style={styles.spinner} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.bg },
  logoWrap: { marginBottom: spacing.xl },
  logoGradient: {
    width: 96,
    height: 96,
    borderRadius: radius.xl,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: colors.blue,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 20,
    elevation: 12,
  },
  spinner: { marginTop: spacing.lg },
});
