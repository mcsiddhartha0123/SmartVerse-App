import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Modal,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Plus, Search, Pin, Trash2, X, BookOpen, Clock } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { colors, spacing, radius, font } from '@/constants/theme';

interface Note {
  id: string;
  title: string;
  content: string;
  subject: string;
  is_pinned: boolean;
  created_at: string;
  updated_at: string;
}

const SUBJECTS = ['General', 'DSP', 'VLSI', 'Microprocessors', 'Communication', 'EM Theory', 'Networks', 'Lab'];

const SUBJECT_COLORS: Record<string, string> = {
  General: colors.textMuted,
  DSP: colors.blue,
  VLSI: '#A855F7',
  Microprocessors: colors.success,
  Communication: colors.warning,
  'EM Theory': '#EC4899',
  Networks: '#06B6D4',
  Lab: colors.error,
};

function timeAgo(dateStr: string) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

export default function NotesScreen() {
  const { user } = useAuth();
  const [notes, setNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterSubject, setFilterSubject] = useState('All');
  const [modalVisible, setModalVisible] = useState(false);
  const [editNote, setEditNote] = useState<Note | null>(null);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [subject, setSubject] = useState('General');
  const [saving, setSaving] = useState(false);

  const loadNotes = async () => {
    if (!user) return;
    setLoading(true);
    const { data } = await supabase
      .from('notes')
      .select('*')
      .eq('user_id', user.id)
      .order('is_pinned', { ascending: false })
      .order('updated_at', { ascending: false });
    if (data) setNotes(data);
    setLoading(false);
  };

  useEffect(() => { loadNotes(); }, [user]);

  const openNew = () => {
    setEditNote(null);
    setTitle('');
    setContent('');
    setSubject('General');
    setModalVisible(true);
  };

  const openEdit = (note: Note) => {
    setEditNote(note);
    setTitle(note.title);
    setContent(note.content);
    setSubject(note.subject);
    setModalVisible(true);
  };

  const save = async () => {
    if (!title.trim()) return;
    setSaving(true);
    if (editNote) {
      await supabase.from('notes').update({ title, content, subject, updated_at: new Date().toISOString() }).eq('id', editNote.id);
    } else {
      await supabase.from('notes').insert({ title, content, subject });
    }
    setSaving(false);
    setModalVisible(false);
    loadNotes();
  };

  const togglePin = async (note: Note) => {
    await supabase.from('notes').update({ is_pinned: !note.is_pinned }).eq('id', note.id);
    loadNotes();
  };

  const deleteNote = async (id: string) => {
    await supabase.from('notes').delete().eq('id', id);
    setNotes(notes.filter(n => n.id !== id));
  };

  const filtered = notes.filter(n => {
    const matchSearch = n.title.toLowerCase().includes(search.toLowerCase()) ||
      n.content.toLowerCase().includes(search.toLowerCase());
    const matchSubject = filterSubject === 'All' || n.subject === filterSubject;
    return matchSearch && matchSubject;
  });

  return (
    <View style={styles.container}>
      <SafeAreaView edges={['top']} style={styles.safeArea}>
        <View style={styles.header}>
          <View>
            <Text style={styles.pageTitle}>My Notes</Text>
            <Text style={styles.pageSubtitle}>{notes.length} notes saved</Text>
          </View>
          <TouchableOpacity style={styles.addBtn} onPress={openNew} activeOpacity={0.85}>
            <LinearGradient colors={[colors.blue, colors.blueDark]} style={styles.addBtnGrad}>
              <Plus size={20} color="#fff" strokeWidth={2} />
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* Search */}
        <View style={styles.searchWrap}>
          <Search size={16} color={colors.textMuted} strokeWidth={1.5} style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            value={search}
            onChangeText={setSearch}
            placeholder="Search notes..."
            placeholderTextColor={colors.textMuted}
          />
        </View>

        {/* Subject Filter */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filterRow}
        >
          {['All', ...SUBJECTS].map(s => (
            <TouchableOpacity
              key={s}
              style={[styles.filterChip, filterSubject === s && styles.filterChipActive]}
              onPress={() => setFilterSubject(s)}
            >
              <Text style={[styles.filterChipText, filterSubject === s && styles.filterChipTextActive]}>
                {s}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
          {loading ? (
            <ActivityIndicator color={colors.blue} style={{ marginTop: 40 }} />
          ) : filtered.length === 0 ? (
            <View style={styles.emptyState}>
              <BookOpen size={48} color={colors.border} strokeWidth={1} />
              <Text style={styles.emptyTitle}>No notes yet</Text>
              <Text style={styles.emptySubtitle}>Tap + to add your first note</Text>
            </View>
          ) : (
            filtered.map(note => (
              <TouchableOpacity
                key={note.id}
                style={styles.noteCard}
                onPress={() => openEdit(note)}
                activeOpacity={0.85}
              >
                {note.is_pinned && (
                  <View style={styles.pinnedBadge}>
                    <Pin size={10} color={colors.blue} strokeWidth={2} />
                    <Text style={styles.pinnedText}>Pinned</Text>
                  </View>
                )}
                <View style={styles.noteHeader}>
                  <View style={[styles.subjectTag, { backgroundColor: (SUBJECT_COLORS[note.subject] || colors.textMuted) + '22' }]}>
                    <Text style={[styles.subjectTagText, { color: SUBJECT_COLORS[note.subject] || colors.textMuted }]}>
                      {note.subject}
                    </Text>
                  </View>
                  <View style={styles.noteActions}>
                    <TouchableOpacity onPress={() => togglePin(note)} style={styles.noteActionBtn}>
                      <Pin
                        size={15}
                        color={note.is_pinned ? colors.blue : colors.textMuted}
                        strokeWidth={note.is_pinned ? 2.5 : 1.5}
                      />
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => deleteNote(note.id)} style={styles.noteActionBtn}>
                      <Trash2 size={15} color={colors.error} strokeWidth={1.5} />
                    </TouchableOpacity>
                  </View>
                </View>
                <Text style={styles.noteTitle}>{note.title}</Text>
                {note.content ? (
                  <Text style={styles.noteContent} numberOfLines={2}>{note.content}</Text>
                ) : null}
                <View style={styles.noteFooter}>
                  <Clock size={11} color={colors.textMuted} strokeWidth={1.5} />
                  <Text style={styles.noteTime}>{timeAgo(note.updated_at)}</Text>
                </View>
              </TouchableOpacity>
            ))
          )}
          <View style={{ height: 80 }} />
        </ScrollView>
      </SafeAreaView>

      {/* Add/Edit Modal */}
      <Modal visible={modalVisible} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.modalKAV}>
            <View style={styles.modalCard}>
              <View style={styles.modalHeader}>
                <Text style={styles.modalTitle}>{editNote ? 'Edit Note' : 'New Note'}</Text>
                <TouchableOpacity onPress={() => setModalVisible(false)}>
                  <X size={22} color={colors.textSecondary} strokeWidth={1.5} />
                </TouchableOpacity>
              </View>

              <Text style={styles.modalLabel}>Subject</Text>
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                style={styles.subjectScroll}
              >
                {SUBJECTS.map(s => (
                  <TouchableOpacity
                    key={s}
                    style={[styles.subjectChip, subject === s && { borderColor: SUBJECT_COLORS[s], backgroundColor: SUBJECT_COLORS[s] + '22' }]}
                    onPress={() => setSubject(s)}
                  >
                    <Text style={[styles.subjectChipText, subject === s && { color: SUBJECT_COLORS[s] }]}>{s}</Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>

              <Text style={styles.modalLabel}>Title</Text>
              <TextInput
                style={styles.modalInput}
                value={title}
                onChangeText={setTitle}
                placeholder="Note title..."
                placeholderTextColor={colors.textMuted}
              />

              <Text style={styles.modalLabel}>Content</Text>
              <TextInput
                style={[styles.modalInput, styles.modalTextarea]}
                value={content}
                onChangeText={setContent}
                placeholder="Write your notes here..."
                placeholderTextColor={colors.textMuted}
                multiline
                numberOfLines={6}
                textAlignVertical="top"
              />

              <TouchableOpacity
                style={[styles.saveBtn, !title.trim() && styles.saveBtnDisabled]}
                onPress={save}
                disabled={!title.trim() || saving}
                activeOpacity={0.85}
              >
                <LinearGradient
                  colors={[colors.blue, colors.blueDark]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={styles.saveBtnGrad}
                >
                  {saving
                    ? <ActivityIndicator color="#fff" />
                    : <Text style={styles.saveBtnText}>Save Note</Text>
                  }
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </KeyboardAvoidingView>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  safeArea: { flex: 1 },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
  },
  pageTitle: { fontSize: font.xxl, fontWeight: '800', color: colors.textPrimary },
  pageSubtitle: { fontSize: font.sm, color: colors.textSecondary, marginTop: 2 },
  addBtn: { borderRadius: radius.full, overflow: 'hidden' },
  addBtnGrad: { width: 44, height: 44, borderRadius: radius.full, alignItems: 'center', justifyContent: 'center' },
  searchWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bgCard,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    marginHorizontal: spacing.md,
    paddingHorizontal: spacing.md,
    height: 44,
    marginBottom: spacing.sm,
  },
  searchIcon: { marginRight: spacing.sm },
  searchInput: { flex: 1, color: colors.textPrimary, fontSize: font.sm },
  filterRow: {
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.sm,
    gap: spacing.xs,
  },
  filterChip: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: radius.full,
    backgroundColor: colors.bgCard,
    borderWidth: 1,
    borderColor: colors.border,
  },
  filterChipActive: { backgroundColor: colors.blueGlow, borderColor: colors.blue },
  filterChipText: { fontSize: font.xs, color: colors.textSecondary, fontWeight: '600' },
  filterChipTextActive: { color: colors.blue },
  scroll: { paddingHorizontal: spacing.md },
  emptyState: { alignItems: 'center', paddingTop: 60, gap: spacing.sm },
  emptyTitle: { fontSize: font.lg, fontWeight: '600', color: colors.textSecondary },
  emptySubtitle: { fontSize: font.sm, color: colors.textMuted },
  noteCard: {
    backgroundColor: colors.bgCard,
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.sm,
    borderWidth: 1,
    borderColor: colors.border,
  },
  pinnedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    marginBottom: 6,
  },
  pinnedText: { fontSize: font.xs, color: colors.blue, fontWeight: '600' },
  noteHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: spacing.xs },
  subjectTag: {
    paddingHorizontal: spacing.sm,
    paddingVertical: 2,
    borderRadius: radius.sm,
  },
  subjectTagText: { fontSize: font.xs, fontWeight: '700' },
  noteActions: { flexDirection: 'row', gap: spacing.xs },
  noteActionBtn: { padding: 4 },
  noteTitle: { fontSize: font.md, fontWeight: '700', color: colors.textPrimary, marginBottom: 4 },
  noteContent: { fontSize: font.sm, color: colors.textSecondary, lineHeight: 20, marginBottom: spacing.xs },
  noteFooter: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: spacing.xs },
  noteTime: { fontSize: font.xs, color: colors.textMuted },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'flex-end',
  },
  modalKAV: { width: '100%' },
  modalCard: {
    backgroundColor: colors.bgCard,
    borderTopLeftRadius: radius.xl,
    borderTopRightRadius: radius.xl,
    padding: spacing.lg,
    borderTopWidth: 1,
    borderColor: colors.border,
  },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: spacing.md },
  modalTitle: { fontSize: font.xl, fontWeight: '700', color: colors.textPrimary },
  modalLabel: { fontSize: font.xs, fontWeight: '600', color: colors.textSecondary, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: spacing.xs },
  subjectScroll: { marginBottom: spacing.md },
  subjectChip: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: radius.full,
    borderWidth: 1,
    borderColor: colors.border,
    marginRight: spacing.xs,
    backgroundColor: colors.bgElevated,
  },
  subjectChipText: { fontSize: font.xs, color: colors.textSecondary, fontWeight: '600' },
  modalInput: {
    backgroundColor: colors.bgElevated,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
    color: colors.textPrimary,
    fontSize: font.md,
    marginBottom: spacing.md,
  },
  modalTextarea: { height: 120, textAlignVertical: 'top' },
  saveBtn: { borderRadius: radius.md, overflow: 'hidden' },
  saveBtnDisabled: { opacity: 0.5 },
  saveBtnGrad: { height: 52, alignItems: 'center', justifyContent: 'center' },
  saveBtnText: { color: '#fff', fontSize: font.md, fontWeight: '700' },
});
