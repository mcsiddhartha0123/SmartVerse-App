import { Tabs } from 'expo-router';
import { LayoutDashboard, Calculator, BookOpen, Briefcase, Crown } from 'lucide-react-native';
import { colors } from '@/constants/theme';
import { StyleSheet, View } from 'react-native';

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: styles.tabBar,
        tabBarActiveTintColor: colors.blue,
        tabBarInactiveTintColor: colors.textMuted,
        tabBarLabelStyle: styles.label,
        tabBarBackground: () => <View style={styles.tabBg} />,
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Dashboard',
          tabBarIcon: ({ size, color }) => <LayoutDashboard size={size} color={color} strokeWidth={1.8} />,
        }}
      />
      <Tabs.Screen
        name="cgpa"
        options={{
          title: 'CGPA',
          tabBarIcon: ({ size, color }) => <Calculator size={size} color={color} strokeWidth={1.8} />,
        }}
      />
      <Tabs.Screen
        name="notes"
        options={{
          title: 'Notes',
          tabBarIcon: ({ size, color }) => <BookOpen size={size} color={color} strokeWidth={1.8} />,
        }}
      />
      <Tabs.Screen
        name="internships"
        options={{
          title: 'Internships',
          tabBarIcon: ({ size, color }) => <Briefcase size={size} color={color} strokeWidth={1.8} />,
        }}
      />
      <Tabs.Screen
        name="premium"
        options={{
          title: 'Premium',
          tabBarIcon: ({ size, color }) => <Crown size={size} color={color} strokeWidth={1.8} />,
        }}
      />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    position: 'absolute',
    borderTopWidth: 1,
    borderTopColor: 'rgba(30,45,69,0.8)',
    height: 64,
    paddingBottom: 8,
    paddingTop: 4,
    elevation: 0,
    backgroundColor: 'transparent',
  },
  tabBg: {
    flex: 1,
    backgroundColor: 'rgba(17,24,39,0.97)',
  },
  label: {
    fontSize: 10,
    fontWeight: '600',
    marginTop: -2,
  },
});
