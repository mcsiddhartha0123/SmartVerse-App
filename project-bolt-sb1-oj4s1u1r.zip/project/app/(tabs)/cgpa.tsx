import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Plus, Trash2, Save, TrendingUp, RotateCcw, ChevronDown, ChevronUp, History, Clock, BarChart3 } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { colors, spacing, radius, font } from '@/constants/theme';

interface CGPARecord {
  id: string;
  label: string;
  cgpa: number;
  semester: number;
  created_at: string;
}

interface Course {
  id: string;
  name: string;
  credits: string;
  grade: string;
}

const GRADE_POINTS: Record<string, number> = {
  O: 10, 'A+': 9, A: 8, 'B+': 7, B: 6, C: 5, F: 0,
};

const GRADES = ['O', 'A+', 'A', 'B+', 'B', 'C', 'F'];

const DEFAULT_ECE_COURSES: Course[] = [
  { id: '1', name: 'Digital Signal Processing', credits: '4', grade: 'A' },
  { id: '2', name: 'VLSI Design', credits: '3', grade: 'A+' },
  { id: '3', name: 'Microprocessors', credits: '4', grade: 'B+' },
  { id: '4', name: 'Communication Systems', credits: '4', grade: 'A' },
  { id: '5', name: 'EM Theory', credits: '3', grade: 'B+' },
];

function gradeColor(grade: string) {
  if (grade === 'O' || grade === 'A+') return colors.success;
  if (grade === 'A' || grade === 'B+') return colors.blue;
  if (grade === 'B' || grade === 'C') return colors.warning;
  return colors.error;
}

export default function CGPAScreen() {
  const { user } = useAuth();
  const [courses, setCourses] = useState<Course[]>(DEFAULT_ECE_COURSES);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [expandGrade, setExpandGrade] = useState<string | null>(null);
  const [history, setHistory] = useState<CGPARecord[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  const loadHistory = async () => {
    if (!user) return;
    const { data } = await supabase
      .from('cgpa_records')
      .select('id, label, cgpa, semester, created_at')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(10);
    if (data) setHistory(data);
  };

  useEffect(() => { loadHistory(); }, [user]);

  const calcCGPA = () => {
    let totalWeighted = 0;
    let totalCredits = 0;
    for (const c of courses) {
      const cr = parseFloat(c.credits) || 0;
      const gp = GRADE_POINTS[c.grade] ?? 0;
      totalWeighted += cr * gp;
      totalCredits += cr;
    }
    return totalCredits > 0 ? totalWeighted / totalCredits : 0;
  };

  const cgpa = calcCGPA();

  const addCourse = () => {
    setCourses([...courses, { id: Date.now().toString(), name: '', credits: '3', grade: 'A' }]);
  };

  const removeCourse = (id: string) => {
    setCourses(courses.filter(c => c.id !== id));
  };

  const updateCourse = (id: string, field: keyof Course, value: string) => {
    setCourses(courses.map(c => c.id === id ? { ...c, [field]: value } : c));
  };

  const reset = () => {
    setCourses(DEFAULT_ECE_COURSES);
    setSaved(false);
  };

  const saveCGPA = async () => {
    if (!user) return;
    setSaving(true);
    const { error } = await supabase.from('cgpa_records').insert({
      label: 'Calculated CGPA',
      cgpa,
      semester: 1,
      courses: courses,
    });
    setSaving(false);
    if (!error) {
      setSaved(true);
      loadHistory();
      setTimeout(() => setSaved(false), 3000);
    }
  };

  const deleteRecord = async (id: string) => {
    await supabase.from('cgpa_records').delete().eq('id', id);
    setHistory(history.filter((r) => r.id !== id));
  };

  const cgpaColor =
    cgpa >= 8.5 ? colors.success :
    cgpa >= 7 ? colors.blue :
    cgpa >= 5 ? colors.warning :
    colors.error;

  return (
    <View style={styles.container}>
      <SafeAreaView edges={['top']} style={styles.safeArea}>
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
          {/* Header */}
          <View style={styles.header}>
            <Text style={styles.pageTitle}>CGPA Calculator</Text>
            <Text style={styles.pageSubtitle}>10-point grading scale</Text>
          </View>

          {/* CGPA Display */}
          <LinearGradient
            colors={['#0F2440', '#1A2235']}
            style={styles.resultCard}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
          >
            <View style={styles.resultLeft}>
              <Text style={styles.resultLabel}>Current CGPA</Text>
              <Text style={[styles.resultValue, { color: cgpaColor }]}>
                {cgpa.toFixed(2)}
              </Text>
              <Text style={styles.resultSub}>
                {cgpa >= 9 ? 'Outstanding!' : cgpa >= 8 ? 'Excellent!' : cgpa >= 7 ? 'Very Good' : cgpa >= 6 ? 'Good' : 'Keep Going!'}
              </Text>
            </View>
            <View style={styles.resultRight}>
              <TrendingUp size={56} color={cgpaColor} strokeWidth={1} style={{ opacity: 0.2 }} />
            </View>
          </LinearGradient>

          {/* Grade Reference */}
          <View style={styles.gradeRef}>
            {Object.entries(GRADE_POINTS).map(([g, pts]) => (
              <View key={g} style={[styles.gradeChip, { borderColor: gradeColor(g) + '55' }]}>
                <Text style={[styles.gradeChipGrade, { color: gradeColor(g) }]}>{g}</Text>
                <Text style={styles.gradeChipPts}>{pts}</Text>
              </View>
            ))}
          </View>

          {/* Courses */}
          <View style={styles.section}>
            <View style={styles.sectionHeaderRow}>
              <Text style={styles.sectionTitle}>Courses ({courses.length})</Text>
              <TouchableOpacity style={styles.addBtn} onPress={addCourse} activeOpacity={0.8}>
                <Plus size={16} color={colors.blue} strokeWidth={2} />
                <Text style={styles.addBtnText}>Add</Text>
              </TouchableOpacity>
            </View>

            {courses.map((course, idx) => (
              <View key={course.id} style={styles.courseCard}>
                <View style={styles.courseRow1}>
                  <TextInput
                    style={styles.courseNameInput}
                    value={course.name}
                    onChangeText={(v) => updateCourse(course.id, 'name', v)}
                    placeholder={`Course ${idx + 1}`}
                    placeholderTextColor={colors.textMuted}
                  />
                  <TouchableOpacity
                    style={styles.removeBtn}
                    onPress={() => removeCourse(course.id)}
                  >
                    <Trash2 size={16} color={colors.error} strokeWidth={1.5} />
                  </TouchableOpacity>
                </View>
                <View style={styles.courseRow2}>
                  <View style={styles.creditsWrap}>
                    <Text style={styles.fieldLabel}>Credits</Text>
                    <TextInput
                      style={styles.creditsInput}
                      value={course.credits}
                      onChangeText={(v) => updateCourse(course.id, 'credits', v)}
                      keyboardType="numeric"
                      maxLength={1}
                    />
                  </View>
                  <View style={styles.gradeWrap}>
                    <Text style={styles.fieldLabel}>Grade</Text>
                    <TouchableOpacity
                      style={styles.gradePicker}
                      onPress={() => setExpandGrade(expandGrade === course.id ? null : course.id)}
                    >
                      <Text style={[styles.gradePickerText, { color: gradeColor(course.grade) }]}>
                        {course.grade}
                      </Text>
                      {expandGrade === course.id
                        ? <ChevronUp size={14} color={colors.textMuted} strokeWidth={2} />
                        : <ChevronDown size={14} color={colors.textMuted} strokeWidth={2} />
                      }
                    </TouchableOpacity>
                    {expandGrade === course.id && (
                      <View style={styles.gradeDropdown}>
                        {GRADES.map(g => (
                          <TouchableOpacity
                            key={g}
                            style={[styles.gradeOption, course.grade === g && styles.gradeOptionActive]}
                            onPress={() => { updateCourse(course.id, 'grade', g); setExpandGrade(null); }}
                          >
                            <Text style={[styles.gradeOptionText, { color: gradeColor(g) }]}>{g}</Text>
                            <Text style={styles.gradeOptionPts}>{GRADE_POINTS[g]} pts</Text>
                          </TouchableOpacity>
                        ))}
                      </View>
                    )}
                  </View>
                  <View style={styles.gpWrap}>
                    <Text style={styles.fieldLabel}>Weighted</Text>
                    <Text style={styles.gpValue}>
                      {((parseFloat(course.credits) || 0) * (GRADE_POINTS[course.grade] ?? 0)).toFixed(0)}
                    </Text>
                  </View>
                </View>
              </View>
            ))}
          </View>

          {/* CGPA Analytics - simple bar chart */}
          {history.length >= 2 && (
            <View style={styles.section}>
              <View style={styles.sectionHeader}>
                <BarChart3 size={18} color={colors.blue} strokeWidth={1.5} />
                <Text style={styles.sectionTitle}>CGPA Trend</Text>
              </View>
              <View style={styles.chartContainer}>
                {history.slice(0, 6).reverse().map((rec, idx) => {
                  const hColor =
                    rec.cgpa >= 8.5 ? colors.success :
                    rec.cgpa >= 7 ? colors.blue :
                    rec.cgpa >= 5 ? colors.warning : colors.error;
                  const height = Math.max(20, (Number(rec.cgpa) / 10) * 80);
                  return (
                    <View key={rec.id} style={styles.chartBar}>
                      <View style={[styles.barVal, { height, backgroundColor: hColor }]} />
                      <Text style={styles.chartLabel}>S{rec.semester}</Text>
                    </View>
                  );
                })}
              </View>
            </View>
          )}

          {/* CGPA History */}
          <View style={styles.section}>
            <TouchableOpacity
              style={styles.sectionHeader}
              onPress={() => setShowHistory(!showHistory)}
              activeOpacity={0.8}
            >
              <History size={18} color={colors.blue} strokeWidth={1.5} />
              <Text style={styles.sectionTitle}>Saved Records ({history.length})</Text>
              {showHistory
                ? <ChevronUp size={16} color={colors.textMuted} strokeWidth={2} />
                : <ChevronDown size={16} color={colors.textMuted} strokeWidth={2} />
              }
            </TouchableOpacity>
            {showHistory && (
              history.length === 0 ? (
                <View style={styles.emptyHistory}>
                  <Text style={styles.emptyHistoryText}>No saved records yet. Save your CGPA below.</Text>
                </View>
              ) : (
                history.map((rec) => {
                  const hColor =
                    rec.cgpa >= 8.5 ? colors.success :
                    rec.cgpa >= 7 ? colors.blue :
                    rec.cgpa >= 5 ? colors.warning : colors.error;
                  return (
                    <View key={rec.id} style={styles.historyCard}>
                      <View style={styles.historyLeft}>
                        <View style={[styles.historyDot, { backgroundColor: hColor }]} />
                        <View>
                          <Text style={styles.historyLabel}>Sem {rec.semester}</Text>
                          <View style={styles.historyTimeRow}>
                            <Clock size={11} color={colors.textMuted} strokeWidth={1.5} />
                            <Text style={styles.historyTime}>
                              {new Date(rec.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                            </Text>
                          </View>
                        </View>
                      </View>
                      <Text style={[styles.historyCgpa, { color: hColor }]}>{Number(rec.cgpa).toFixed(2)}</Text>
                      <TouchableOpacity onPress={() => deleteRecord(rec.id)} style={styles.historyDelete}>
                        <Trash2 size={15} color={colors.error} strokeWidth={1.5} />
                      </TouchableOpacity>
                    </View>
                  );
                })
              )
            )}
          </View>

          <View style={styles.actionsRow}>
            <TouchableOpacity style={styles.resetBtn} onPress={reset} activeOpacity={0.8}>
              <RotateCcw size={16} color={colors.textSecondary} strokeWidth={1.5} />
              <Text style={styles.resetBtnText}>Reset</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.saveBtn, (saving || saved) && styles.saveBtnDone]}
              onPress={saveCGPA}
              disabled={saving}
              activeOpacity={0.85}
            >
              <LinearGradient
                colors={saved ? [colors.success, '#059669'] : [colors.blue, colors.blueDark]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.saveBtnGrad}
              >
                <Save size={16} color="#fff" strokeWidth={1.5} />
                <Text style={styles.saveBtnText}>
                  {saving ? 'Saving...' : saved ? 'Saved!' : 'Save CGPA'}
                </Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>

          <View style={{ height: 80 }} />
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  safeArea: { flex: 1 },
  scroll: { paddingHorizontal: spacing.md },
  header: { paddingVertical: spacing.md },
  pageTitle: { fontSize: font.xxl, fontWeight: '800', color: colors.textPrimary },
  pageSubtitle: { fontSize: font.sm, color: colors.textSecondary, marginTop: 2 },
  resultCard: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: radius.xl,
    padding: spacing.lg,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: 'rgba(59,130,246,0.2)',
    overflow: 'hidden',
  },
  resultLeft: { flex: 1 },
  resultLabel: { fontSize: font.sm, color: colors.textSecondary, fontWeight: '600', marginBottom: 4 },
  resultValue: { fontSize: 52, fontWeight: '800', lineHeight: 60 },
  resultSub: { fontSize: font.sm, color: colors.textMuted, marginTop: 4 },
  resultRight: { opacity: 1 },
  gradeRef: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.xs,
    marginBottom: spacing.md,
  },
  gradeChip: {
    alignItems: 'center',
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderRadius: radius.sm,
    borderWidth: 1,
    backgroundColor: colors.bgCard,
    minWidth: 42,
  },
  gradeChipGrade: { fontSize: font.xs, fontWeight: '700' },
  gradeChipPts: { fontSize: 10, color: colors.textMuted },
  section: { marginBottom: spacing.md },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs, marginBottom: spacing.sm },
  sectionHeaderRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: spacing.sm },
  sectionTitle: { fontSize: font.md, fontWeight: '700', color: colors.textPrimary },
  addBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: colors.blueGlow,
    borderRadius: radius.full,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderWidth: 1,
    borderColor: 'rgba(59,130,246,0.3)',
  },
  addBtnText: { color: colors.blue, fontSize: font.sm, fontWeight: '600' },
  courseCard: {
    backgroundColor: colors.bgCard,
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.xs,
    borderWidth: 1,
    borderColor: colors.border,
  },
  courseRow1: { flexDirection: 'row', alignItems: 'center', marginBottom: spacing.sm, gap: spacing.sm },
  courseNameInput: {
    flex: 1,
    color: colors.textPrimary,
    fontSize: font.sm,
    fontWeight: '500',
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    paddingVertical: 4,
  },
  removeBtn: { padding: spacing.xs },
  courseRow2: { flexDirection: 'row', gap: spacing.sm, alignItems: 'flex-end' },
  fieldLabel: { fontSize: font.xs, color: colors.textMuted, marginBottom: 4, fontWeight: '600', textTransform: 'uppercase' },
  creditsWrap: { width: 72 },
  creditsInput: {
    backgroundColor: colors.bgElevated,
    borderRadius: radius.sm,
    color: colors.textPrimary,
    fontSize: font.md,
    fontWeight: '700',
    textAlign: 'center',
    height: 36,
    borderWidth: 1,
    borderColor: colors.border,
  },
  gradeWrap: { flex: 1, position: 'relative', zIndex: 10 },
  gradePicker: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.bgElevated,
    borderRadius: radius.sm,
    paddingHorizontal: spacing.sm,
    height: 36,
    borderWidth: 1,
    borderColor: colors.border,
  },
  gradePickerText: { fontSize: font.md, fontWeight: '700' },
  gradeDropdown: {
    position: 'absolute',
    top: 56,
    left: 0,
    right: 0,
    backgroundColor: colors.bgElevated,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    zIndex: 100,
    overflow: 'hidden',
  },
  gradeOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  gradeOptionActive: { backgroundColor: colors.blueGlow },
  gradeOptionText: { fontSize: font.sm, fontWeight: '700' },
  gradeOptionPts: { fontSize: font.xs, color: colors.textMuted },
  gpWrap: { width: 72, alignItems: 'center' },
  gpValue: {
    fontSize: font.lg,
    fontWeight: '700',
    color: colors.textPrimary,
    textAlign: 'center',
    paddingVertical: 6,
  },
  actionsRow: { flexDirection: 'row', gap: spacing.md, marginBottom: spacing.lg },
  chartContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    height: 100,
    backgroundColor: colors.bgCard,
    borderRadius: radius.md,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
    gap: spacing.sm,
  },
  chartBar: { flex: 1, alignItems: 'center', justifyContent: 'flex-end' },
  barVal: { width: '100%', borderRadius: radius.sm, minHeight: 20 },
  chartLabel: { fontSize: font.xs, color: colors.textMuted, marginTop: 4 },
  emptyHistory: {
    backgroundColor: colors.bgCard,
    borderRadius: radius.md,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
    marginTop: spacing.xs,
  },
  emptyHistoryText: { fontSize: font.sm, color: colors.textMuted, textAlign: 'center' },
  historyCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bgCard,
    borderRadius: radius.md,
    padding: spacing.md,
    marginTop: spacing.xs,
    borderWidth: 1,
    borderColor: colors.border,
  },
  historyLeft: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, flex: 1 },
  historyDot: { width: 10, height: 10, borderRadius: 5 },
  historyLabel: { fontSize: font.sm, fontWeight: '700', color: colors.textPrimary },
  historyTimeRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 2 },
  historyTime: { fontSize: font.xs, color: colors.textMuted },
  historyCgpa: { fontSize: font.xl, fontWeight: '800', marginRight: spacing.md },
  historyDelete: { padding: spacing.xs },
  resetBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    flex: 1,
    justifyContent: 'center',
    height: 52,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.bgCard,
  },
  resetBtnText: { color: colors.textSecondary, fontSize: font.sm, fontWeight: '600' },
  saveBtn: { flex: 2 },
  saveBtnDone: {},
  saveBtnGrad: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.xs,
    height: 52,
    borderRadius: radius.md,
  },
  saveBtnText: { color: '#fff', fontSize: font.md, fontWeight: '700' },
});
